#include <stdio.h>
main()
{
	float i, j;
	printf("Insira um valor:");
	scanf("%f", &i);
	printf("Insira outro valor:");
	scanf("%f", &j);
	printf("resultado: %.1f", (i+j)/2);
}
