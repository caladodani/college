#include <stdio.h>
// A defini��o do TipoAniversario faz-se antes do main
typedef struct
{
		char nome[20];
		char apelido[20];
		int ano,mes,dia;
	} TipoAniversario;
	int main(void)
	{
	// Declara��o de Vari�veis
	TipoAniversario ListaAniversarios[20];
	int i;
	int num =0;
	int cond= 1;
	// Dados de entrada
	/*printf("Inisira o numero de aniversariantes(Maximo 20):\n");
	scanf("%d",&num);
	if(num>20)
	{
		perror("Numero de aniversariantes exedido");
		return 0;
	}*/
	
	printf("\nPrograma para inserir o anivers�rio de %d amigos\n ", num );
	for(i=0;(cond==1 )&& (i<20); i++)
	{
		printf("\nInsira o nome do aniversariante: " );
		scanf("%s", ListaAniversarios[i].nome);
		printf("Insira o apelido do aniversariante: " );
		scanf("%s", ListaAniversarios[i].apelido);
		printf("Insira o dia do aniversario: " );
		scanf("%d", &ListaAniversarios[i].dia);
		printf("Insira o mes do aniversario: " );
		scanf("%d", &ListaAniversarios[i].mes);
		printf("Insira o ano do aniversario: " );
		scanf("%d", &ListaAniversarios[i].ano);
		printf("\nSe pretende adicionar mais um introduza 1:");
		scanf("%d",&cond);
		
	}
	// Dados de saida
	num=i;
	if(cond!=1)
		printf("Fim de acrescento de aniversarios");
	if(i==20)
		printf("Lista cheia");
	printf("\n");
	for(i=0; i<num; i++)
	{
		printf("%s %s ", ListaAniversarios[i].nome, ListaAniversarios[i].apelido);
		printf("faz anos no dia %d / %d / %d \n", ListaAniversarios[i].dia,
		 ListaAniversarios[i].mes,
		 ListaAniversarios[i].ano);
	}
	return 0;
}
