#include <stdio.h>
main()
{
	int i, j;
	printf("Insira um valor:");
	scanf("%d", &i);
	printf("Insira outro valor:");
	scanf("%d", &j);
	while (i<j)
	{
		
		i++;
		j--;
	}
	printf("resultado: %d", i);
	
}
