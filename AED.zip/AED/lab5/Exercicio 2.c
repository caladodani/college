// Codigo B
#include <stdio.h>
main()
{
	 printf("%-15s %5.1f %5.1f\n", "Lisboa", 2.4444, 52.0);
	 printf("%-15s %5.1f %5.1f\n", "Brasilia", 23.23123, 32.1);
	 printf("%-15s %5.1f %5.1f\n", "Goa", 3.444, 0.01);
	 printf("%-15s %5.1f %5.1f\n", "Cidade-do-Cabo", 32.4444, 52.0);
	 printf("%-15s %5.1f %5.1f\n", "Moscovo", -11.531, 52.0);
	 printf("%-15s %5.1f %5.1f\n", "Covilha", 22.0, 52.0);
}

