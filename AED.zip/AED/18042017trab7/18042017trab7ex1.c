#include <stdio.h>
//Defini��o de estrutura
typedef struct{
	int nota;

	int par;
	int maior_10;
}TipoNota;
//subproramas 
int M10(num)
{
	if ( num >= 10)
		return 1;
	else 
		return 0;
	
}

int paridade(int num)
{
	if ((num %2)== 0)
		return 1;
	else 
		return 0;
}
void Resultados(int total,float med,int pos)
{

	printf("Numero de Notas:%d\n",total);
	printf("Media das Notas:%.2f\n",med);
	printf("Notas positivas:%d\n",pos);

	
}
//Programa Principal
int main()
{
	//Declara��o de variaveis
	TipoNota v_Notas[1000];
	FILE*fNotas;
	FILE*fpositivas;
	int i=0;
	int j=0;
	int cont=0;
	float soma =0;
	float media =0;
	int v_notas_positivas[1000];
	
	//Leitura de dados 
	
	fNotas= fopen ("notas.txt","r");
	if (fNotas == NULL)
		perror("Erro, nao foi possivel abrir o ficheiro \n");
	while (fscanf(fNotas,"%d",&v_Notas[i].nota)!=EOF)
	{

		//printf("%d\n",v_Notas[i].nota);
		i++;
	}
	fclose(fNotas);
	//Algoritmo
	cont =i;
	for(i=0; i<cont; i++)
	{
		v_Notas[i].maior_10 = M10(v_Notas[i].nota);
		v_Notas[i].par = paridade(v_Notas[i].nota);
	}
	for (i=0 ; i<cont; i++)
	{
		soma = v_Notas[i].nota +soma;
		if (v_Notas[i].maior_10 ==1)
			{
				v_notas_positivas[j]=v_Notas[i].nota;
				j++;
			}
	}
	media = soma/ cont;
	fpositivas = fopen("notas_positivas.txt","w");
	for (i=0;i<cont;i++)
	{
		fprintf(fpositivas,"%d\n",v_notas_positivas[i]);
	}
	fclose(fpositivas);
	//Apresenta��o de Resultados
	Resultados(cont, media,j);
	
}
