#include <stdio.h>
//Defini��o de tipo
typedef struct{
	char nome[50];
	char apelido[50];
	int meses;
	int sala;
}TipoAluno;

//Subprogrma de Atribui��o de sala 
int AtribuiSala(idade)
{
	if(idade <= 12)
		return 1;
	if((idade > 12)&&(idade<=24))
		return 2;
	if((idade > 24)&&(idade<=36))
		return 3;
	if((idade > 36)&&(idade<=48))
		return 4;
	if((idade > 48)&&(idade<=60))
		return 5;
	if((idade > 60)&&(idade<=72))
		return 6;

}




int main()
{
	//Delclara��o de Variaveis
	TipoAluno ListaAlunos[50];
	FILE*falunos;
	FILE*fsalas;
	int i=0;
	int cont =0;
	int v_salas[7];
	//Inicializa��o de salas
	v_salas[1]=0;
	v_salas[2]=0;
	v_salas[3]=0;
	v_salas[4]=0;
	v_salas[5]=0;
	v_salas[6]=0;
	//Leitura de dados 
	falunos=fopen("lista_inscritos.txt", "r");
	if (falunos == NULL)
		perror("Erro, nao foi possivel abrir o ficheiro \n");
	while (fscanf(falunos,"%s", ListaAlunos[i].nome)!=EOF)
	{
		fscanf(falunos,"%s %d",ListaAlunos[i].apelido, &ListaAlunos[i].meses);
		i++;
	}
	// Algoritmo
	cont=i;
	fclose(falunos);
	for (i=0;i<cont;i++)
	{
		ListaAlunos[i].sala= AtribuiSala(ListaAlunos[i].meses);
		if(ListaAlunos[i].sala == 1)
			v_salas[1] ++;
		if(ListaAlunos[i].sala == 2)
			v_salas[2] ++;
		if(ListaAlunos[i].sala == 3)
			v_salas[3] ++;
		if(ListaAlunos[i].sala == 4)
			v_salas[4] ++;
		if(ListaAlunos[i].sala == 5)
			v_salas[5] ++;
		if(ListaAlunos[i].sala == 6)
			v_salas[6] ++;
	}
	//Apresenta��o de resultados
	fsalas=fopen("salas.txt","w");
	fprintf(fsalas,"Sala 1: %d\n",v_salas[1]);
	fprintf(fsalas,"Sala 2: %d\n",v_salas[2]);
	fprintf(fsalas,"Sala 3: %d\n",v_salas[3]);
	fprintf(fsalas,"Sala 4: %d\n",v_salas[4]);	
	fprintf(fsalas,"Sala 5: %d\n",v_salas[5]);
	fprintf(fsalas,"Sala 6: %d\n",v_salas[6]);
	fclose(fsalas);
	printf ("Ficheiro de Salas criado com sucesso...");
	
}
