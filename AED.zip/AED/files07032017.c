#include <stdio.h>

int main () {
	//Delara��o de variaveis
	FILE*fContactos;
	int nrTlf;
	int mes;
	int ano;
	int dia;
	int i;
	char PrimeiroNome[50];
	char SegundoNome[50];
	
	//Leitura de dados
	fContactos = fopen ("contactos.txt","r+");
	while (fscanf(fContactos,"%s",PrimeiroNome)!=EOF)
	{
		
		fscanf(fContactos, "%s%d%d%d%d",SegundoNome,&nrTlf,&dia,&mes,&ano);
		i++;
		printf("%d- %s %s %d %d %d %d\n\n",i,PrimeiroNome,SegundoNome,nrTlf,dia,mes,ano);
			
	}
	
	fclose (fContactos);
	//algoritmo

	
	//apresenta��o de resultados
	
	printf("Foram lidos %d contactos\n",i);

}
