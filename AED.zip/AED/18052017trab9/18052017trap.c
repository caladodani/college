#include <stdio.h>
#include <stdlib.h>
//*****************************************
//Declara��o de tipos
//*****************************************
typedef struct TipoCliente
{
	char nome[50], apelido[50];
	int NCliente, telefone, compras;
	
}TipoCliente;

typedef struct TipoCelula *Apontador;
typedef struct TipoCelula
{
	TipoCliente cliente;
	Apontador prox;
	Apontador ant;	
}TipoCelula;


typedef struct TipoLista
{
	Apontador primeiro;
	Apontador ultimo;
}TipoLista;

//********************************
//Prototipos de fun��es
//********************************

void InicioLista(TipoLista *ptLista);
void LerFicheiro(TipoLista *ptLista);
void insereCliente(TipoLista *ptLista, TipoCliente Cliente_temp);
void Menu(TipoLista *ptLista);
void LibertaLista(TipoLista *ptLista);
void criaFicheiro(TipoLista *ptLista);
void RemoverC(TipoLista *ptLista);
void imprimeLista(TipoLista *ptLista);
void insereNovoCliente(TipoLista *ptLista);
void OrdenaSelecao(TipoLista *ptLista);
void OrdenaBolha(TipoLista *ptLista);
int OrdemNome(char Nome_1[50],char Nome_2[50]);

// Fun��o Principal
main()
{

	TipoLista ListaClientes;
	//Cria a lista 
	InicioLista(&ListaClientes);
	//Ler ficheiro
	LerFicheiro(&ListaClientes);
	//Abrir Menu
	Menu(&ListaClientes);
	
	

}
//**********************************
// Fun��o InicioLista
//**********************************

void InicioLista(TipoLista *ptLista)
{
	ptLista->primeiro = (Apontador) malloc(sizeof(TipoCelula));
	ptLista->primeiro->prox = NULL;
	ptLista->ultimo = ptLista->primeiro;
}

//**********************************
// Fun��o LerFicheiro
//**********************************
void LerFicheiro(TipoLista *ptLista)
{
	FILE* fr;
	fr=NULL;
	while (fr ==NULL)
	{
		char f[200];
		printf("\nIndroduza o nome do ficheiro a ler:(inclua tipo de ficheiro)\n");
		scanf("%s",f);
		
		
		TipoCliente ClienteTemp;
		
		int i;

		fr = fopen(f, "r");	
		for(i=0; fscanf(fr, "%s %s %d %d %d", ClienteTemp.nome, ClienteTemp.apelido, &ClienteTemp.NCliente,&ClienteTemp.telefone, &ClienteTemp.compras) != EOF; i++)
			insereCliente(ptLista, ClienteTemp);
		fclose(fr);
		if(fr==NULL)
			printf("\nFicheiro nao existe...\n");
		
	}

	

}

//***********************************************
// Fun��o: insereCliente
//***********************************************

void insereCliente(TipoLista *ptLista, TipoCliente ClienteTemp)
{
	Apontador temp;
	ptLista->ultimo->prox = (Apontador) malloc(sizeof(TipoCelula));
	temp=ptLista->ultimo;
	
	ptLista->ultimo = ptLista->ultimo->prox;
	
	ptLista->ultimo->cliente = ClienteTemp; 
	ptLista->ultimo->ant = temp;	

	ptLista->ultimo->prox = NULL;
}
//**********************************
// Fun��o ImprimeLista
//**********************************

void imprimeLista(TipoLista *ptLista)
{
	Apontador p,t;
	int soma =0;
	p = ptLista->primeiro->prox;
	int n = 0;	
	float media;
	int i;
	int conta=0;
	int opcao=0;
	
	// Escolha de forma de ordena�ao
	while ((opcao!=1)&&(opcao!=2))
	{
		printf("\nIntroduza 1 se pertende ordenar por Numero de cliente:\n ");
		printf("\nIntroduza 2 se pertende ordenar por Nome de cliente:\n");
		scanf("%d",&opcao);
		printf("\n");
	}
	if(opcao==1)
		OrdenaSelecao(ptLista);
	if(opcao==2)
		OrdenaBolha(ptLista);
	
	while (p != NULL) 
	{
	    printf("Nome:%-10s %-9s %9d Telefone:%9d Numero de Compras:%4d\n", p->cliente.nome, p->cliente.apelido, p->cliente.NCliente, p->cliente.telefone,p->cliente.compras);
		soma =soma + p->cliente.compras;
		{
			i=0;
			while (!(p->cliente.nome[i]=='\0'))
			{
				i++;			
			}
			if (i>conta)
			{
				conta= i;
				t =p;
			}
		}
		p = p->prox;
		n++;
	}

	media=soma/n;
	printf("%d Clientes\n",n);
	printf("Media de Compras de Clientes: %.2f\n",media);
	printf("O maior nome e: %s\n\n\n",t->cliente.nome);
}
//**********************************
// Fun��o OrdenaSeleao
//**********************************
void OrdenaSelecao(TipoLista *ptLista)
{	
	Apontador p, q, p_menor;
	TipoCliente temp;
	p = ptLista->primeiro->prox;
	while (p != NULL) 
	{
	   	p_menor = p;
	   	q = p->prox;
	
		while(q != NULL)
		{
			if(q->cliente.NCliente < p_menor->cliente.NCliente)								p_menor = q;
			q = q->prox;
		}
	if(p!=p_menor)
	{
		temp = p->cliente;
		p->cliente = p_menor->cliente;
		p_menor->cliente = temp;
		}
		p = p->prox;
	}
}

//**********************************
// Fun��o OrdenaBolha
//**********************************
void OrdenaBolha(TipoLista *ptLista)
{
	Apontador p, q;
	TipoCliente temp;
	
	p = ptLista->primeiro->prox;
		
	while (p != NULL) 
	{
	    q = ptLista->ultimo;
		while(q != p)
		{
			
			if((OrdemNome(q->cliente.nome,q->ant->cliente.nome)==2)) 		
			{
				temp = q->cliente;
				q->cliente = q->ant->cliente;
				q->ant->cliente = temp;				
			}
			if(OrdemNome(q->cliente.nome,q->ant->cliente.nome)==3)		
			{
				if(OrdemNome(q->cliente.apelido,q->ant->cliente.apelido)==2)
				{
					temp = q->cliente;
					q->cliente = q->ant->cliente;
					q->ant->cliente = temp;
				}
				
			}
			
		    q = q->ant;
		}
		p = p->prox;
	}

}
// Fun��o LibertaLista
//**********************************
void Libertalista(TipoLista *ptLista)
{
	Apontador p;
	
	p = ptLista->primeiro;	
	while (p != NULL) {
	    ptLista->primeiro = ptLista->primeiro->prox;
	    free(p);
	    p = ptLista->primeiro;
	}
}
//**********************************
// Fun��o Criar ficheiro
//**********************************
void criaFicheiro(TipoLista *ptLista)
{
	FILE*fw;
	fw = fopen("ListaNumeroDeClientes.txt","w");
	Apontador p;
	
	p = ptLista->primeiro->prox;	
	while (p != NULL) 
	{
	    fprintf(fw,"%s %d \n", p->cliente.nome, p->cliente.NCliente);
	    p = p->prox;
	}
	fclose(fw);
}
//**********************************
// Fun��o Remover
//**********************************
void RemoverC(TipoLista *ptLista)
{
	int numero=0;
	int encontra=0;
	Apontador p,t;
	printf("Introduza o numero de cliente a remover:\n");
	scanf("%d",&numero);
	
	
	p = ptLista->primeiro->prox;
	int n = 0;	
	while ((p != NULL)||(encontra!=1)) 
	{
	    if(p->cliente.NCliente==numero)
	    {
	    	t=p;
	    	p->ant->prox=p->prox;
	    	free(p);

	    	printf("\nCliente %s %s removido...\n",t->cliente.nome,t->cliente.apelido);
	    	encontra=1;
	    }
	    	
		p = p->prox;
	}
	if (encontra==0)
		printf("\nCliente nao encotrado...\n");
}
//***********************************************
// Fun��o: Insere Novo Cliente
//***********************************************

void insereNovoCliente(TipoLista *ptLista)
{
	TipoCliente ClienteTemp;
	printf("Introduza o Nome:\n");
	scanf("%s",ClienteTemp.nome);
	printf("Introduza o Aplido:\n");
	scanf("%s",ClienteTemp.apelido);
	printf("Introduza o Numero de Cliente:\n");
	scanf("%d",&ClienteTemp.NCliente);
	printf("Introduza o telefone:\n");
	scanf("%d",&ClienteTemp.telefone);
	printf("Introduza o numero de compras:\n");
	scanf("%d",&ClienteTemp.compras);
	ptLista->ultimo->prox = (Apontador ) malloc(sizeof(TipoCelula));
	ptLista->ultimo = ptLista->ultimo->prox;		
	ptLista->ultimo->cliente = ClienteTemp;
	ptLista->ultimo->prox = NULL;
	
	printf("\nCliente introduzido com sucesso...\n");
}
//**********************************
// Fun��o OrdemNome
//**********************************
int OrdemNome(char Nome_1[50],char Nome_2[50])
{
	//se o proximo nome for maior (Daniel<Ana) o resultado � 1
	//se o proximo nome for menor (Ana>Daniel) o resultado � 2
	//se os nomes forem iguais o resultado � 3
	//Declara��o de Variaveis
	int i=0;
	int j=0;
	int conta=0;
	//Algoritmo
	
	while (!(Nome_1[i]=='\0'))
	{
		i++;
	}
	while (!(Nome_2[j]=='\0'))
	{
		j++;
	}
	while ((!(Nome_1[conta]=='\0'))&&(!(Nome_2[conta]=='\0')))
	{
		if (Nome_1[conta] > Nome_2[conta])
		{
			return 1;
	
		}
			
		if (Nome_1[conta] < Nome_2[conta])
		{
			return 2;
		}
		conta++;	
	}
	if (Nome_1[conta] == Nome_2[conta])
	{
		return 3;	
	}
	if (((Nome_1[conta]=='\0') )|| (Nome_2[conta]=='\0'))
	{
		if (i< j)
			return 1;
		if (i> j)
			return 2;
	}

	
}
//**********************************
// Fun��o Menu
//**********************************
void Menu(TipoLista *ptLista)
{

	int opcao;
	while (opcao!=5)
	{
		printf("1-Listar informacao da lista.\n");
		printf("2-Remover contacto\n");
		printf("3-Introduzir novo Cliente\n");
		printf("4-Gravar lista de Clientes\n");
		printf("5-Terminar:\n");
		scanf("%d",&opcao);
		switch (opcao)
		{
			case 1:imprimeLista(ptLista);
				break;
			case 2:RemoverC(ptLista);
				break;
			case 3:insereNovoCliente(ptLista);
				break;
			case 4:criaFicheiro(ptLista);
				break;
			case 5:{
				Libertalista(ptLista);
				printf("Fim do Programa...");
				break;}
			default: printf("Opcao Invalida...\n");

		}

	}
	
		
}

