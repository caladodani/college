#include <stdio.h>
#include <stdlib.h>

typedef struct TipoCelula *Apontador;
typedef struct 
{
	int valor;
	Apontador porx;
}TipoCelula;
Apontador p;
/* 
imprime(TipoLista *ptLista)
{
	TipoCelula *p;
	p=ptLista->primeiro->prox;	
	
	while (p!=NULL)
	{
		printf("%d",p->valor);
		p=p->prox;
	}
}*/
