#include <stdio.h>

//subprogramas 


//Programa do n� de valores no vector 
void valores(int min,int max,int *intervalo)
{
	//Declara��o de Variaveis
	int i=0;
	int val=0;

	

	//Leitura de dados e algoritmo
	while (i<total(intervalo))
	{
		if(intervalo[i] >= min && intervalo[i] <= max)
			val++;
		
		i++;
	}
	printf("valores:%d\n",val);
}


//Programa da soma dos elementos do intrevalo
void soma(int min,int max,int *intervalo)
{
	//Declara��o de variaveis
	int i=0;
	int soma=0;


	//Leitura de dados e Algoritmo
	while (i<total(intervalo))
	{
		if(intervalo[i] >= min && intervalo[i] <= max)
			soma = intervalo[i]+soma;
			
		
		i++;
	}
	printf("Soma: %d\n",soma);
}


//Programa da media
void media(int min,int max,int *intervalo)
{
	//Declara��o de variaveis 
	int i=0;
	int c=0;
	int soma=0;
	float media=0.00;

	//Leitura de dados e Algoritmo
	while (i<total(intervalo))
	{
		if(intervalo[i] >= min && intervalo[i] <= max)
			soma = intervalo[i]+soma;
			
		
		i++;
	}
	i=0;
	while (i<total(intervalo))
	{
		if(intervalo[i] >= min && intervalo[i] <= max)
			c++;
		
		i++;
	}
	
	media =(float) soma / c;
	printf("Media %.2f\n",media);
}


//Programa do n� de dados no vector
int total (int *intervalo)
{
	//Declara��o de Variaveis 
	int tam=0;
	
	//Leitura de dados de algoritmo
	
	while (intervalo[tam] != 420)/*A utiliza��o do \0 para fim de vector n�o fuciona pois existem valores 0*/
	{//Coloqueim um elento com o valor de 420 para determinar o fim do vector

		tam++;
	}
	
	return tam;
	
}


//Progrma de Apresenta��o de Resultados 
void resultados (int min, int max, int *intervalo)
{
	
	printf("O numero de valores lidos do vetor e igual a: %d\n",total(intervalo) );
	valores(min, max,intervalo);
	soma(min, max, intervalo);
	media(min,max,intervalo);
	
}
	
main()
{
	//Introdu��o de vari�veis
	
	int v_numeros[700];
	int numero;
	int min=0;
	int max=0;
	int i=0;
	FILE*fNumerosIntervalo;
	FILE*fNumeros;
	
	//Leitura de dados
	
	fNumeros = fopen("numeros.txt", "r");
	
	if (fNumeros == NULL)
			perror("Erro, nao foi possivel abrir o ficheiro \n");
			
	else
		while((fscanf (fNumeros, "%d \n", &numero)) != EOF)
		{
			v_numeros[i] = numero;
			i++;	
	    }
	    
	    printf("Introduza o numero minimo:\n");
	    scanf("%d", &min);
	    
	    printf("Introduza o numero maximo:\n");
	    scanf("%d", &max);
	fclose(fNumeros);   
	
	//Algoritmo da Impress�o no ficheiro 
	
	i=0;
	fNumerosIntervalo = fopen("numeros_intervalo.txt","w");
	fprintf(fNumerosIntervalo,"      Posicao |    Valor\n");
	while (i<total(v_numeros))
	{
		if(v_numeros[i] >= min && v_numeros[i] <= max)
			fprintf(fNumerosIntervalo,"        %d�    |     %d\n",i+1, v_numeros[i]);
			
		
		i++;
	}
	fclose(fNumerosIntervalo);
	printf("Foi criado um ficheiro com os valores do intervalo...\n");
	

	//Apresenta��o de Resultados
	
	resultados(min,max,v_numeros);

	
}


