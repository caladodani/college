#include <stdio.h>
//Subprogramas
FILE*fresultados;
void produto(a,b)
{
	
	fresultados =fopen ("resultados.txt","w");
	fprintf(fresultados,"%d * %d = %d",a,b, a*b);
	fclose(fresultados);
	printf("Ficheiro resultados.txt criado...");
}
void soma(a,b)
{

	fresultados =fopen ("resultados.txt","w");
	fprintf(fresultados,"%d + %d = %d",a,b, a+b);
	fclose(fresultados);
	printf("Ficheiro resultados.txt criado...");
}
void subtracao(a,b)
{

	fresultados =fopen ("resultados.txt","w");
	fprintf(fresultados,"%d - %d = %d",a,b, a-b);
	fclose(fresultados);
	printf("Ficheiro resultados.txt criado...");
}
void divisao(a,b)
{
	
	fresultados =fopen ("resultados.txt","w");
	fprintf(fresultados,"%d / %d = %.2f",a ,b ,(float) a/b);
	fclose(fresultados);
	printf("Ficheiro resultados.txt criado...");
}
//Programa Principal
int main()
{
	//Declara��o de variaveis
	int a=0,b=0;
	char opcao='+';


	
	
	//Leitura de dados
	printf("Introduza o valor de a:\n");
	scanf("%d",&a);
	printf("Introduza o valor de b:\n");
	scanf("%d",&b);
	printf("-Introduza '+' para a soma de a+b\n");
	printf("-Introduza '-' para a subtracao de a-b\n");
	printf("-Introduza '*' para a multiplicacao de a*b\n");
	printf("-Introduza '/' para a divisao de a+b\n");
	printf("Indroduzir operador:");
	
	scanf(" %c",&opcao);

	//Algoritmo
	switch (opcao)
	{
		case '+':soma(a,b);
			break;
		case '-':subtracao(a,b);
			break;
		case '*':produto(a,b);
			break;
		case '/':divisao(a,b);
			break;
		default:printf("opcao invalida");
	}
}
