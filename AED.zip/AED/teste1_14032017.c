#include <stdio.h>
int main()
{
	//Declara�ao de variaveis
	
	int a;
	int b;
	int i;
	int opcao;
	int res;
	float resultado;
	
	//Leitura de dados
	
	printf(" Insira dois numeros(a e b) inteiros com valores entre 3 e 27,\n e que seja multiplo de 3\n");
	printf("Insisira a:\n");
	scanf("%d",&a);
	printf("Insira b:\n");
	scanf("%d",&b);
	opcao= 1;
	i=1;
	resultado=0;
	
	//Algoritmo
	
	while ((i<4)&& ((a%3!=0)||(b%3!=0)||((a<3)||(a>27))||((b <3)||b >27)))
	{
		printf("Numeros invalidos\n");
		printf(" Insira dois numeros(a e b) inteiros com valores entre 3 e 27,\n e que seja multiplo de 3\n");
		printf("Insisira a:\n");
		scanf("%d",&a);
		printf("Insira b:\n");
		scanf("%d",&b);
		i++;	
	}
	if (i==4)
	{
		printf("Fim de programa");
		return 0;	
	}

	if (!((a%3!=0)||(b%3!=0)||((a<3)||(a>27))||((b<3)||b>27)))
	{
		printf("Escolha entre as opcoes:\n");
		printf("1-Divisao b/a:\n");
		printf("2-Subtracao entre a e b:\n");
		printf("3-Fatorial de a:\n");
		scanf("%d",&opcao);
		


		if (opcao == 1)
		{
			
			resultado=b/a;
		}
		if(opcao == 2)
		{
			
			res = a -b;
						
		}
		if (opcao==3)
		{
			res =1;
			while (a >0)
			{
					res = a * (res);
					a--;
			}
		}
		
		//Apresenta��o de resultados
		
		switch(opcao)
		{
			case 1: printf("b/a=%.2f\n",resultado);
				break;
			case 2:	printf("a-b =:%d",res);
				break;
			case 3: printf("O factorial de a e: %d",res);
				break;
			default:printf("opcao invalida");
		}


		
		
			
	}

	
}
