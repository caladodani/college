#include <stdio.h>
#include <stdlib.h>
//*****************************************
//Declara��o de tipos
//*****************************************
typedef struct 
{
	char nome[100], apelido[100], email[100];
	int idade, telefone;
	
}TipoAmigo;

typedef struct TipoCelula
{
	TipoAmigo amigo;
	struct TipoCelula *prox;	
}TipoCelula;

typedef struct 
{
	TipoCelula *primeiro;
	TipoCelula *ultimo;
}TipoLista;

//********************************
//Prototipos de fun��es
//********************************
void ListaVazia(TipoLista *ptLista);
void LerFicheiro(TipoLista *ptLista);
void insereAmigo(TipoLista *ptLista, TipoAmigo Amigo_temp);
void Menu(TipoLista *ptLista);
void LibertaLista(TipoLista *ptLista);
void criaFicheiro(TipoLista *ptLista);
void RemoverC(TipoLista *ptLista);
void imprimeLista(TipoLista *ptLista);

// Fun��o Principal
main()
{

	TipoLista ListaAmigos;
	//Cria a lista 
	ListaVazia(&ListaAmigos);
	//Ler ficheiro
	LerFicheiro(&ListaAmigos);
	//Abrir Menu
	Menu(&ListaAmigos);
	
	

}
//**********************************
// Fun��o ListaVazia
//**********************************

void ListaVazia(TipoLista *ptLista)
{
	ptLista->primeiro = (TipoCelula *) malloc(sizeof(TipoCelula));
	ptLista->primeiro->prox = NULL;
	ptLista->ultimo = ptLista->primeiro;
}

//**********************************
// Fun��o LerFicheiro
//**********************************
void LerFicheiro(TipoLista *ptLista)
{	
	TipoAmigo AmigoTemp;
	FILE* fr;
	int i;

	fr = fopen("ListaDeAmigos.txt", "r");	
	
	for(i=0; fscanf(fr, "%s %s %d %d %s", AmigoTemp.nome, AmigoTemp.apelido, &AmigoTemp.idade,&AmigoTemp.telefone,AmigoTemp.email) != EOF; i++)
		insereAmigo(ptLista, AmigoTemp);
	fclose(fr);
}

//***********************************************
// Fun��o: insere_no_fim
//
// Descri��o: isere um novo Escritor no fim da lista
//
//***********************************************

void insereAmigo(TipoLista *ptLista, TipoAmigo AmigoTemp)
{
	ptLista->ultimo->prox = (TipoCelula *) malloc(sizeof(TipoCelula));
	ptLista->ultimo = ptLista->ultimo->prox;		
	ptLista->ultimo->amigo = AmigoTemp; // copia as estruturas diretamente		

	ptLista->ultimo->prox = NULL;
}
//**********************************
// Fun��o ImprimeLista
//**********************************

void imprimeLista(TipoLista *ptLista)
{
	TipoCelula *p;
	
	p = ptLista->primeiro->prox;
	int n = 0;	
	while (p != NULL) 
	{
	    printf("%-15s %-15s %3d %9d %-12s\n", p->amigo.nome, p->amigo.apelido, p->amigo.idade, p->amigo.telefone, p->amigo.email);
		p = p->prox;
		n++;
	}
	printf("%d Contactos",n);
}
//**********************************
// Fun��o LibertaLista
//**********************************
void Libertalista(TipoLista *ptLista)
{
	TipoCelula *p;
	
	p = ptLista->primeiro;	
	while (p != NULL) {
	    ptLista->primeiro = ptLista->primeiro->prox;
	    free(p);
	    p = ptLista->primeiro;
	}
}
//**********************************
// Fun��o Criar ficheiro
//**********************************
void criaFicheiro(TipoLista *ptLista)
{
	FILE*fw;
	fw = fopen("ListaEmails.txt","w");
	TipoCelula *p;
	
	p = ptLista->primeiro->prox;	
	while (p != NULL) 
	{
	    fprintf(fw,"%s, ", p->amigo.email);
	    p = p->prox;
	}
	fclose(fw);
}
//**********************************
// Fun��o Remover
//**********************************
void RemoverC(TipoLista *ptLista)
{
	int numero=0;
	TipoCelula *p;
	printf("Introduza o telefone de Quem temciona remover:\n");
	scanf("%d",&numero);
	
	
	p = ptLista->primeiro->prox;
	int n = 0;	
	while (p != NULL) 
	{
	    if(p->amigo.telefone==numero)
	    {
	    	free(p);
	    	p = ptLista->primeiro;
	    	printf("Contacto %s %s removido",p->amigo.nome,p->amigo.apelido);
	    	
	    }
	    	
		p = p->prox;
	}
	
}
//**********************************
// Fun��o Menu
//**********************************
void Menu(TipoLista *ptLista)
{

	char opcao;
	printf("A-Listar no ecr� toda a informa��o da lista e calcular o n�mero de amigos da lista.\n");
	printf("B-Remover contacto\n");
	printf("C-Gravar lista de emails\n");
	printf("D-Terminar:\n");
	scanf("%c",&opcao);
	if ((opcao == 'a')||(opcao =='A'))
	{
		imprimeLista(ptLista);
	}	
	if ((opcao == 'b')||(opcao =='B'))
	{
		RemoverC(ptLista);
	}
	if ((opcao == 'c')||(opcao =='C'))
	{
		criaFicheiro(ptLista);
	}	
	if ((opcao == 'd')||(opcao =='D'))
	{
		Libertalista(ptLista);
		printf("Fim do Programa...");
	}
		
}

