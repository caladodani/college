#include <stdio.h>
#include <stdlib.h>
//Defini��o de estruturas
typedef struct Escritor
{
	char nome[20], apelido[20];
	int	ano, idade;

}Escritor ;
typedef struct TipoEscritor
{
	/*char nome[20], apelido[20];
	int	ano, idade;*/
	Escritor item;
	struct TipoEscritor *prox;
}TipoEscritor ;



//fUN��O PEDE ano
int PedeAno(void)
{
	int ano;
	
	printf("Insira o ano atual: ");
	scanf("%d", &ano);
	return ano;
}
void ApresentaResultados (int N_escritores, float idade_media, int N_idades_80_100, char nome[])
{
	printf("\n\nExistem %d escritores. A idade media e de %.1f.\n", N_escritores, idade_media);
	printf("Existem %d escritores com idades compreendidas entre os 80 e os 100 anos.\n", N_idades_80_100);
	printf("O nome mais comprido e %s\n", nome);
}
void CriaFicheiro(TipoEscritor *primeiro)
{
	FILE *f_idades;
	TipoEscritor *p;
	p = primeiro->prox;;
	f_idades = fopen("Idades.txt", "w");
	while (p!= NULL)
	{
		fprintf(f_idades, "%-15s %-15s %5d\n", p->item.nome, p->item.apelido, p->item.idade);
		p = p->prox;
	}
		
	fclose(f_idades);
}
//Programa principal 
int main()
{
	Escritor x;	
	TipoEscritor *Lista_primeiro;
	TipoEscritor *Lista_ultimo;
	FILE *fr_escritores;
	int i,j = 0;
	TipoEscritor *p;
	TipoEscritor *t;
	


	int ano, N_escritores, soma, N_idades_80_100, N_nomes_vogal, Apelido_longo;
	float idade_media;
	int nome_longo; 
	int carateres_nome_longo;
	
	//fun�ao malloc
	Lista_primeiro = (TipoEscritor *) malloc(sizeof(TipoEscritor));
	Lista_primeiro->prox = NULL;
	Lista_ultimo = Lista_primeiro;
	

	//Leitura de Dados
	fr_escritores = fopen("DatasNascimento.txt", "r");
	if (fr_escritores == NULL)
	{
		printf("O ficheiro n�o existe");
		return 0;
	}
	
	for(i=0; fscanf(fr_escritores, "%s %s %d",x.nome,x.apelido,&x.ano) != EOF; i++)
					 {
				 		Lista_ultimo->prox = (TipoEscritor*)malloc(sizeof(TipoEscritor));
				 		Lista_ultimo= Lista_ultimo->prox;
						Lista_ultimo->item=x;

				 		Lista_ultimo->prox = NULL;
					 }
	
	fclose(fr_escritores);	
	
	//Algoritmo
	N_escritores = i;

	ano = PedeAno();
	soma = 0;
	N_idades_80_100 = 0;
	N_nomes_vogal = 0;
	nome_longo = 0; 
	carateres_nome_longo = 0;
	p = Lista_primeiro->prox;
	
	for(i=0; i<N_escritores; i++)
	{
		
		// c�lculo da idade
		p->item.idade=ano - p->item.ano;
		printf(" - %s %d\n", p->item.nome, p->item.idade);

		// variavel auxiliar para calcular a idade m�dia
		soma += p->item.idade;
		
		// Quantidade de escritores entre 80 e 100 anos
		if (80 <= p->item.idade && p->item.idade <=100)
			N_idades_80_100++;
	
		// Pesquisa do nome com mais carateres
		for(j=0; p->item.nome[j] != '\0'; ++j);
		if (j > carateres_nome_longo)
		{
			nome_longo = i;
		}
}
}



