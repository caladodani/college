#include<stdio.h>
#include<stdlib.h>
//estruturas
typedef struct TipoEscritor{
	char nome[20];
	char apelido[20];
	int ano;
	int idade;
}TipoEscritor;

typedef struct Celula{
	TipoEscritor Escritor;
	struct Celula *proximo;
}Celula;

//pede ano
int PedeAno(void)
{
	int ano;
	
	printf("Insira o ano atual: ");
	scanf("%d", &ano);
	return ano;
}
//Criar o ficheiro
int CriaFicheiro(Celula *Lista_primeiro)
{
	Celula *p;
	p = Lista_primeiro->proximo;
	FILE *f_idades;
	f_idades = fopen("Idades.txt", "w");
	p = Lista_primeiro->proximo;
	while (p != NULL)
	{
		fprintf(f_idades, "%-15s %-15s %5d\n", p->Escritor.nome, p->Escritor.apelido, p->Escritor.idade);
 		p = p->proximo;
	}
	fclose(f_idades);
}
//ApresentaResultados
void ApresentaResultados(int contador, float media, int contadorIdade, char nome[])
{
	printf("\n\nExistem %d escritores. A idade media e de %.1f.\n", contador, media);
	printf("Existem %d escritores com idades compreendidas entre os 80 e os 100 anos.\n", contadorIdade);
	printf("O nome mais comprido e %s\n",nome);
}

int main()
{//variaveis
	Celula *Lista_primeiro;
	Celula *Lista_ultimo;
	Celula *p,*t;
	FILE *fr_DataNascimento;
	int Fim=0;
	TipoEscritor x;
	int i,j;
	int ano,idade;
	int contador=0, contadorIdade=0;
	float media; 
	int soma;
	int carateres_nome_longo=0;
	
	//Criar a cabeca da celula
	Lista_primeiro = (Celula *) malloc(sizeof(Celula));
	Lista_primeiro->proximo = NULL;
	Lista_ultimo = Lista_primeiro;
	
	//Abrir ficheiro e escrever na lista
	fr_DataNascimento = fopen("DatasNascimento.txt", "r");
	if (fr_DataNascimento == NULL)
	{
		printf("O ficheiro n�o existe");
		return 0;
	}
	for(i=0; fscanf(fr_DataNascimento, "%s %s %d",x.nome, x.apelido, &x.ano) != EOF; i++)
	{
		Lista_ultimo->proximo = (Celula *) malloc(sizeof(Celula));
		Lista_ultimo = Lista_ultimo->proximo;
		Lista_ultimo->Escritor = x; 
		Lista_ultimo->proximo = NULL;
	}
	fclose(fr_DataNascimento);	
	
	// Percorre a Lista 
	ano = PedeAno();
	printf("fijdsfjlsls\n");
	p = Lista_primeiro->proximo;
	while (p != NULL)
	{
 	    idade = ano - p->Escritor.ano;
 		p->Escritor.idade = idade;
 		printf(" - %s %d\n", p->Escritor.nome, p->Escritor.idade);
 		contador++;
 		//Para calcular a media
 		soma = soma + idade;
 		
 		//Idade entre 80 e 100
 		if(idade>80 && idade<100)
 			contadorIdade++;
 			
 		//Nome com mais caracteres	
 		for(j=0; p->Escritor.nome[j] != '\0'; ++j);
		if (j > carateres_nome_longo)
		{
			carateres_nome_longo = j;
			t = p;
		}
		
 		p = p->proximo;
 		
 	}
 	
 	//calcula a media 
 	media=(float) soma/contador;
 	
 	CriaFicheiro(Lista_primeiro);
 	ApresentaResultados(contador, media, contadorIdade, t->Escritor.nome);
}


