#include <stdio.h>

typedef struct TipoEscritor
{
	char nome[20], apelido[20];
	int	ano, idade;
	struct TipoEscritor *prox;
}TipoEscritor;

int PedeAno(void);
void ApresentaResultados (int N_escritores, float idade_media, int N_idades_80_100, char nome[]);

int main()
{
	// Declara��o de variaveis
	TipoEscritor	ListaEscritores[50];
	FILE *fr_escritores, *fw_escritores;
	int i, j;
	int ano, N_escritores, soma, N_idades_80_100, N_nomes_vogal, Apelido_longo;
	float idade_media;
	int nome_longo; 
	int carateres_nome_longo;
	
	// Leitura de dados	
	fr_escritores = fopen("DatasNascimento.txt", "r");
	if (fr_escritores == NULL)
	{
		printf("O ficheiro n�o existe");
		return 0;
	}
	
	for(i=0; fscanf(fr_escritores, "%s %s %d", 
					ListaEscritores[i].nome,
					ListaEscritores[i].apelido,
					&ListaEscritores[i].ano		) != EOF; i++);
	fclose(fr_escritores);	
				
	// Algoritmo
	N_escritores = i;

	ano = PedeAno();
	soma = 0;
	N_idades_80_100 = 0;
	N_nomes_vogal = 0;
	nome_longo = 0; 
	carateres_nome_longo = 0;
	
	for(i=0; i<N_escritores; i++)
	{
		// c�lculo da idade
		ListaEscritores[i].idade = ano - ListaEscritores[i].ano;

		// variavel auxiliar para calcular a idade m�dia
		soma += ListaEscritores[i].idade;

		// Quantidade de escritores entre 80 e 100 anos
		if (80 <= ListaEscritores[i].idade && ListaEscritores[i].idade <=100)
			N_idades_80_100++;
	
		// Pesquisa do nome com mais carateres
		for(j=0; ListaEscritores[i].nome[j] != '\0'; ++j);
		if (j > carateres_nome_longo)
		{
			nome_longo = i;
			carateres_nome_longo = j;
		}
	}
	
	idade_media = (float) soma/N_escritores;
	
	// Apresenta resultados
	fw_escritores = fopen("Idades.txt", "w");
	for(i=0; i<N_escritores; i++)
		fprintf(fw_escritores, "%-15s %-15s %5d\n", ListaEscritores[i].nome, ListaEscritores[i].apelido, ListaEscritores[i].idade);
	fclose(fw_escritores);
		
	ApresentaResultados (N_escritores, idade_media, N_idades_80_100, ListaEscritores[nome_longo].nome);
	
	return 0;
}


int PedeAno(void)
{
	int ano;
	
	printf("Insira o ano atual: ");
	scanf("%d", &ano);
	return ano;
}

void ApresentaResultados (int N_escritores, float idade_media, int N_idades_80_100, char nome[])
{
	printf("\n\nExistem %d escritores. A idade media e de %.1f.\n", N_escritores, idade_media);
	printf("Existem %d escritores com idades compreendidas entre os 80 e os 100 anos.\n", N_idades_80_100);
	printf("O nome mais comprido e %s\n", nome);
}

