#include <stdio.h>

typedef struct
{
	char nome[20], apelido[20];
	float nota;
	int nivel;
} TipoClassificacao;

int PedeAno(void);
void ApresentaResultados (int ano, int N_escritores, float idade_media, int N_idades_80_100, char nome[]);

int main()
{
	// Declara��o de variaveis
	TipoClassificacao ListaAlunos[50];
	FILE *fr_alunos, *fw_alunos;
	int i, j;
	int ano, N_alunos, N_notas_12_16, N_nomes_vogal;
	float soma;
	float nota_media;
	int nome_longo;
	int carateres_nome_longo;

	// Leitura de dados	
	fr_alunos = fopen("NotasAlunos.txt", "r");
	if (fr_alunos == NULL)
	{
		printf("O ficheiro n�o existe");
		return 0;
	}
	
	for(i=0; fscanf(fr_alunos, "%s %s %f", 
					ListaAlunos[i].nome,
					ListaAlunos[i].apelido,
					&ListaAlunos[i].nota	) != EOF; i++);
	fclose(fr_alunos);	
				
	// Algoritmo
	N_alunos = i;

	ano = PedeAno();
	soma = 0;
	N_notas_12_16 = 0;
	N_nomes_vogal = 0;
	nome_longo = 0;
	carateres_nome_longo = 0;
	
	for(i=0; i<N_alunos; i++)
	{
		if (ListaAlunos[i].nota < 3.5) 
			ListaAlunos[i].nivel = 1;
		else if (ListaAlunos[i].nota < 9.5) 
			ListaAlunos[i].nivel = 2;
		else if (ListaAlunos[i].nota < 13.5) 
			ListaAlunos[i].nivel = 3;
		else if (ListaAlunos[i].nota < 17.5) 
			ListaAlunos[i].nivel = 4;
		else 
			ListaAlunos[i].nivel = 5;

		soma += ListaAlunos[i].nota;

		if (12 <= ListaAlunos[i].nota && ListaAlunos[i].nota <=16)
			N_notas_12_16++;
			
		// Pesquisa do nome com mais carateres
		for(j=0; ListaAlunos[i].nome[j] != '\0'; ++j);
		if (j > carateres_nome_longo)
		{
			nome_longo = i;
			carateres_nome_longo = j;
		}
	}
	
	nota_media = soma/N_alunos;
	
	// Apresenta resultados
	fw_alunos = fopen("Resultados.txt", "w");
	for(i=0; i<N_alunos; i++)
		fprintf(fw_alunos, "%-15s %-15s %5.2f %5d\n", ListaAlunos[i].nome, ListaAlunos[i].apelido, ListaAlunos[i].nota, ListaAlunos[i].nivel);
	fclose(fw_alunos);
	
	ApresentaResultados (ano, N_alunos, nota_media, N_notas_12_16, ListaAlunos[nome_longo].nome);
	
	return 0;
}


int PedeAno(void)
{
	int ano;
	
	printf("Insira o ano atual: ");
	scanf("%d", &ano);
	return ano;
}

void ApresentaResultados (int ano, int N_alunos, float nota_media, int N_notas_12_16, char nome[])
{
	printf("\n\nNo ano de %d existem %d alunos de AED.\n", ano, N_alunos);
	printf("A media das notas e %.2f valores.\n", nota_media);
	printf("Existem %d alunos com notas entre 12 e 16.\n", N_notas_12_16);
	printf("O nome mais comprido e %s.\n\n", nome);	
}

