#include <stdio.h>
//Subprogramas
int produto(a,b)
{
	//Algoritmo
	return a*b;
}
//Programa Principal
int main()
{
	//Declara��o de variaveis
	int a=0,b=0;
	
	//Leitura de dados
	printf("Introduza o valor de a:\n");
	scanf("%d",&a);
	printf("Introduza o valor de b:\n");
	scanf("%d",&b);
	
	//Apresenta��o de Resultados 
	printf( "Produto de a e b =",produto(a,b));
	
}
