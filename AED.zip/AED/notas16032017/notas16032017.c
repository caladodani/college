#include <stdio.h>
int main()
{
	//Declara��o de Variaveis
	FILE*fNotas;
	FILE*fAnaliseNotas;
	float v_notas[50];
	float media=0;
	float soma= 0;
	float maxnotas=0;
	float minnotas=0;
	float notas=0;
	int i=0;
	int neg=0;
	


	
	
	//Leitura do ficheiro
	
	fNotas =fopen ("notas.txt","r");
	while (fscanf(fNotas,"%f",&notas)!=EOF)
		
	{
		v_notas[i]=notas;
		i++;
		printf("%d- %.2f\n",i,notas);	
	}
	fclose(fNotas);
	
	
	//Algoritmo
	i=0;
	while(i<=30)
	{
		soma= soma+v_notas[i];
		i++;
	}
	media=soma/31;

	
	i=0;
	minnotas=v_notas[0];
	while(i<=30)
	{

		
		if (v_notas[i]<minnotas)
		{
			minnotas=v_notas[i];
		}
			
		if (v_notas[i]>maxnotas)
		{
			maxnotas=v_notas[i];
		}
			
		if (10>v_notas[i])
		{
			neg++;
		}
		i++;	
	}
	
	//apresenta��o de resultados 
	fAnaliseNotas =fopen ("Analise_notas.txt","w");
	fprintf(fAnaliseNotas,"Media:%.1f\nnota Minima:%.1f\nnota Maxima:%.1f\nN� de notas a negativas:%d",media,minnotas,maxnotas,neg);
	fclose(fAnaliseNotas);
	printf("\nFicheiro com a anlise de notas foi criado na pasta local");
	
	
	return 0;
	
}
