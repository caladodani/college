#include <stdio.h>

int main (void)
{
	//Declara��o de variaveis
	int i;
	char A[10];
	char B[10];
	char C[10];
	
	//Leitura de Dados 
	
	printf("Introduza o Vector A \n");
	scanf("%s",A);
	
	printf("Introduza o Vector B \n");
	scanf("%s",B);
	
	
	//Algoritmo
	

	

	while ((!(A[i]=='\0'))&&(!(B[i]=='\0')))
	{
		if (A[i] > B[i])
			{
				C[i]= 1;	
			}
			
		if (A[i] < B[i])
			{
				C[i]=-1;
			}
		
		if (A[i] == B[i])
			{
				C[i]=0;
			}
		
		

		i++;
		
	}


	
	
	//Apresenta��o de Resultados
	printf ("O resultado e : \n");
	printf("%c",C);
	return 0;
}
