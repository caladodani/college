#include <stdio.h>

int main (void)
{
	int conta;
	
	char palavra[100];
	printf("introduza palavra\n");
	scanf("%s",palavra);
	while (!(palavra[conta]=='\0'))
	{
		conta++;
		
	}
	printf("Palavra: %s \n",palavra);
	printf ("%d letras",conta);
	
}
