#include <stdio.h>

int main()
{
	int y, x =1;
	int *px;
	px = &x;
	y = *px;
	*px =0;
	printf("%d %d\n",x ,y);
	printf("%d %d %d\n",&x,px ,&y);
	
	char *letter;
	*letter= 'w';
	
	char *message= "palavra";
	return 0;
}
