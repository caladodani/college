#include <stdio.h>
void dinamica(void)
{
	fflush(stdin);
	struct Celula
	{
		TipoItem Item;
		struct Celula
		*prox;
	}
	;
	TipoItem x;
	Celula
	*primeiro,
	*ultimo,
	*p;
	// cria a c�lula cabe�a
	primeiro = (Celula
	*) malloc
	(sizeof
	(Celula));
	primeiro
	-
	>prox = NULL;
	ultimo = primeiro;
	while (1)
	{
		clrscr(); printf("Lista de nomes (Aloca��o Din�mica)
		\n");
		p = primeiro
		->prox;
		while (p != NULL)
		{
			printf("%s
			\n", p
			-
			>Item.nome);
			p = p
			-
			>prox;
		}
		printf("	
		\nInforme um nome, (FIM) para encerrar:
		\n"); gets(x.nome);
		if (strcmp(x.nome, "FIM") == 0)
		break
		;
		// coloca o novo item no final da lista
		ultimo
		-
		>prox = (Celula
		*) malloc
		(sizeof
		(Celula));
		ultimo = ultimo
		-
		>prox;
		ultimo
		-
		>Item = x;
		ultimo
		-
		>prox = NULL
		;
	}
	p = primeiro; // elimina (libera) todos os espa�os de mem�ria alocados
	while (p != NULL)
	{
		primeiro = primeiro
		-
		>prox;
		free(p);
		p = primeiro;
	}
}
