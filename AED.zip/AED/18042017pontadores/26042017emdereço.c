#include <stdio.h>

int main()
{
	int ptr;
	int n = 10;
	int v[5];
	ptr = &n;
	int i;
	printf("N=%d, no endere�o : %x    ptr   %x\n", n ,&n, ptr);
	
	for(i = 0;i<5; i++)
	{
		printf("endere�o : %x\n",&v[i]);
	}
}
