#include <stdio.h>
#include <stdlib.h>

//**************************************************************
// Defini��o de tipos
//**************************************************************
typedef struct
{
	char nome[20];
	char apelido[20];
	int ano;
	int idade;
}TipoEscritor;

typedef struct Celula
{
	TipoEscritor Escritor;
	struct Celula *prox;
}TipoCelula;

typedef struct
{
	TipoCelula *primeiro;
	TipoCelula *ultimo;
	
}TipoLista;

//**************************************************************
//Progrma Le dados 
//**************************************************************

le_dados(TipoLista *ptlista)
{
	
	FILE*ficheiro;
	ficheiro = fopen("DatasNascimento.txt","r");
	TipoEscritor Escritor_aux;
	int i =0;

	if (ficheiro==NULL)
	{
		printf("N�o Existe Ficheiro");
		return 0;
	}
	for (i =0; fscanf(ficheiro,"%s %s %d",Escritor_aux.nome,Escritor_aux.apelido,&Escritor_aux.ano)!=EOF;i++)
	{
		ptlista->ultimo->prox =(TipoCelula*) malloc(sizeof(TipoCelula));
		ptlista->ultimo = ptlista->ultimo->prox;
		ptlista->ultimo->Escritor = Escritor_aux;
		ptlista->ultimo->prox = NULL;
		
	}
	fclose(ficheiro);	
	
}
//**************************************************************
//Progrma Imprime Lista
//**************************************************************
imprime_lista(TipoLista *ptLista)
{
	TipoCelula *p;
	p = ptLista->primeiro->prox;
	while(p!= NULL )
	{
		printf("%s %s %d\n",p->Escritor.nome,p->Escritor.apelido, p->Escritor.idade);
		p=p->prox;
	}
	
}
//**************************************************************
//Progrma Pede Ano
//**************************************************************
int pede_ano()
{
	int ano;
	printf("Introduza ano por fazor:");
	scanf("%d",&ano);
	return ano;
}
//**************************************************************
//Progrma Insere Idade
//**************************************************************
insere_idade(int ano,TipoLista *ptLista)
{
	TipoCelula *p;
	p = ptLista->primeiro->prox;


	while( p!= NULL)
	{
		p->Escritor.idade = ano - p->Escritor.ano;
		//printf("%s %d \n",p->Escritor.nome, p->Escritor.idade);
		p=p->prox;
	}
	
}

//**************************************************************
//Progrma Principal 
//**************************************************************

main()
{
	int ano;
	TipoLista lista;
	//**********************************************************
	// Cria��o do espa�o na memoria
	//**********************************************************
	
	lista.primeiro = (TipoCelula*) malloc(sizeof(TipoEscritor));
	lista.primeiro->prox=NULL;
	lista.ultimo = lista.primeiro;
	// Ler os elementos do ficheiro
	le_dados(&lista);
	
	//Calcular e Inserir a idade 
	ano = pede_ano();
	insere_idade(ano,&lista);
	
	// Imprimir dados 
	imprime_lista(&lista);

	
}

