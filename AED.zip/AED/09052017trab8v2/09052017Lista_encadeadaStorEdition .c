#include <stdio.h>
#include <stdlib.h>

//***********************************************
// Defini��o de tipos
//***********************************************

typedef struct{		// cada Escritor da lista corresponde a um registro
  char nome[30];		
  char apelido[30];		
  int ano;		
  int idade;
} TipoEscritor;

typedef struct Celula {
    TipoEscritor Escritor;
    struct Celula *prox;
}Celula;

typedef struct{
	Celula *primeiro;
	Celula *ultimo;
} TipoLista;

//***********************************************
// Prot�tipos de fun��es
//***********************************************

void le_dados(TipoLista *ptLista);
void insere_no_fim(TipoLista *ptLista, TipoEscritor Escritor_aux);
int pede_ano(void);
void insere_idade(TipoLista *ptLista);
void imprime_lista(TipoLista *ptLista);
void apaga_lista(TipoLista *ptLista);
void criaFicheiro(TipoLista *ptLista);

//***********************************************
// Fun�ao: main
//***********************************************

int main() 
{
	TipoLista Lista;
	
	// cria a c�lula cabe�a
	Lista.primeiro = (Celula *) malloc(sizeof(Celula));
	Lista.primeiro->prox = NULL;
	Lista.ultimo = Lista.primeiro;

	// Le os elementos do ficheiro para a Lista
	le_dados(&Lista);

	// insere idade	
	insere_idade(&Lista);


	// imprime todos os elementos da Lista
	imprime_lista(&Lista);
		
	//Imprime ficheiro
	criaFicheiro(&Lista);

	// elimina (liberta) todos os espa�os de mem�ria alocados
	apaga_lista(&Lista);
	
	

}
//***********************************************
// Fun��o: le_dados
//
// Descri��o: fun��o para leitura de dados do  
//            ficheiro e inser��o na lista
//***********************************************

void le_dados(TipoLista *ptLista)
{	
	TipoEscritor Escritor_aux;
	FILE* fr;
	int i;

	fr = fopen("DatasNascimento.txt", "r");	
	
	for(i=0; fscanf(fr, "%s %s %d", Escritor_aux.nome, Escritor_aux.apelido, &Escritor_aux.ano) != EOF; i++)
		insere_no_fim(ptLista, Escritor_aux);
	fclose(fr);
}

//***********************************************
// Fun��o: insere_no_fim
//
// Descri��o: isere um novo Escritor no fim da lista
//
//***********************************************

void insere_no_fim(TipoLista *ptLista, TipoEscritor Escritor_aux)
{
	ptLista->ultimo->prox = (Celula *) malloc(sizeof(Celula));
	ptLista->ultimo = ptLista->ultimo->prox;		
	ptLista->ultimo->Escritor = Escritor_aux; // copia as estruturas diretamente		

	ptLista->ultimo->prox = NULL;
}

//***********************************************
// Fun��o: insere_idade
//
// Descri��o: calcula e insere a idade de cada escritor
//
//***********************************************
void insere_idade(TipoLista *ptLista)
{
	
	Celula *p;
	int ano;
		
	ano = pede_ano();
	
	p = ptLista->primeiro;	
	while (p != NULL) 
	{
		p->Escritor.idade = ano - p->Escritor.ano;
	    p = p->prox;
	}
}

//***********************************************
// Fun��o: imprime_lista
//
// Descri��o: imprime a lista de autores com suas idades
//
//***********************************************
	
void imprime_lista(TipoLista *ptLista)
{
	Celula *p;
	
	p = ptLista->primeiro->prox;	
	while (p != NULL) 
	{
	    printf("%-12s %-12s %4d\n", p->Escritor.nome, p->Escritor.apelido, p->Escritor.idade);
	    p = p->prox;
	}
}
//***********************************************
// Fun��o: apaga_lista
//
// Descri��o: apaga a lista
//
//***********************************************

void apaga_lista(TipoLista *ptLista)
{
	Celula *p;
	
	p = ptLista->primeiro;	
	while (p != NULL) {
	    ptLista->primeiro = ptLista->primeiro->prox;
	    free(p);
	    p = ptLista->primeiro;
	}
}

//***********************************************
// Fun��o: pede_ano
//
// Descri��o: pede o ano
//
//***********************************************

int pede_ano(void)
{
	int ano;
	
	printf("Insira o ano atual: ");
	scanf("%d", &ano);
	return ano;
}
//***********************************************
// Fun��o: cria ficheiro com lista
//
// Descri��o: imprime a lista de autores com suas idades
//
//***********************************************
	
void criaFicheiro(TipoLista *ptLista)
{
	FILE*fidades;
	fidades = fopen("Idades.txt","w");
	Celula *p;
	
	p = ptLista->primeiro->prox;	
	while (p != NULL) 
	{
	    fprintf(fidades,"%-12s %-12s %4d\n", p->Escritor.nome, p->Escritor.apelido, p->Escritor.idade);
	    p = p->prox;
	}
	fclose(fidades);
}


