#include <stdio.h>
//Defini��o de estrutura
typedef struct{
	char nome[50];
	char apelido[50];
	float nota;
	int nivel;
}TipoClassificacao;

//Subprogramas
int PedeAno()
{
	int ano =0;
	printf("Indroduza o ano actual:\n");
	scanf("%d",&ano);
	return ano;
}
//Subprograma de apresenta��o de resultados
void ApresentaResultados(int Ano,int n,float m,int v,char *max)
{
	printf("\nAno:%d\n",Ano);
	printf("Numero de Alunos:%d\n",n);
	printf("Media das Notas:%.2f\n",m);
	printf("Notas entre 12 e 16:%d\n",v);
	printf("Nome mais comprido:%s\n",max);
	
	
}
//Progrma Principal
int main()
{
	//Declara��o de variaveis
	int maior=0;
	int max=0;
	int j=0;
	int val =0;
	float soma=0;
	float media = 0;
	int cont=0;
	int ano=0;
	int i = 0;
	TipoClassificacao ListaAlunos[50];
	FILE*fResultados;
	FILE*fNotas;
	
	
	//Leitura de dados
	fNotas=fopen("NotasAlunos.txt","r");
	while (fscanf(fNotas,"%s",ListaAlunos[i].nome)!=EOF)
	{
		fscanf(fNotas, "%s %f",ListaAlunos[i].apelido,&ListaAlunos[i].nota);
		//printf("%s %s %.3f\n",ListaAlunos[i].nome,ListaAlunos[i].apelido,ListaAlunos[i].nota);
		i++;
		
		
	}
	cont = i;
	fclose(fNotas);
	ano =PedeAno();
	
	//Algoritmo
	for (i=0; i<cont; i++)
	{
		if (ListaAlunos[i].nota>= 0 && ListaAlunos[i].nota <3.5 )
			ListaAlunos[i].nivel = 1;
		if (ListaAlunos[i].nota>= 3.5 && ListaAlunos[i].nota <9.5 )
			ListaAlunos[i].nivel = 2;		
		if (ListaAlunos[i].nota>= 9.5 && ListaAlunos[i].nota <13.5 )
			ListaAlunos[i].nivel = 3;
		if (ListaAlunos[i].nota>= 13.5 && ListaAlunos[i].nota <17.5 )
			ListaAlunos[i].nivel = 4;			
		if (ListaAlunos[i].nota>= 17.5 && ListaAlunos[i].nota <=20 )
			ListaAlunos[i].nivel = 5;			
					
	}
	for (i=0; i<cont; i++)
	{
		soma = ListaAlunos[i].nota + soma;
		
		
	}
	media = (float) soma/cont;
	for (i=0; i<cont; i++)
	{
		if (ListaAlunos[i].nota>= 12 && ListaAlunos[i].nota <=16 )
			val++;
		
	}
	i=0;
	while(i<cont)
	{
		for(j = 0;ListaAlunos[i].nome[j]!= '\0';j++)
		{
			if (j>max)
			{
				maior = i;
				max = j;
			}
		}
		i++;
	}
	//Apresenta��o de Resultados 
	fResultados= fopen("Resultados.txt","w");
	i= 0;
	while (i<cont)
	{
		
		//fprintf(fResultados,"%s %s %.2f %d\n",ListaAlunos[i].nome,ListaAlunos[i].apelido,ListaAlunos[i].nota,ListaAlunos[i].nivel);
		fprintf(fResultados,"%-10s %-11s ",ListaAlunos[i].nome,ListaAlunos[i].apelido);
	
		fprintf(fResultados,"%15.2f ",ListaAlunos[i].nota);

		fprintf(fResultados,"%15d\n",ListaAlunos[i].nivel);		
		i++;
	}
	
	ApresentaResultados(ano,cont,media,val,ListaAlunos[maior].nome);
	
	
}
