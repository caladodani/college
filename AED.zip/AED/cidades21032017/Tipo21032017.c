#include <stdio.h>
//Declara��o de estruturas
typedef struct {
	char nome[20];
	float tempf;
	float tempc;
}TipoCidade;

int main()
{
	//Declara��o de variaveis
	TipoCidade cidades[50];
	FILE*fTemperaturasF;
	FILE*fTemperaturasC;
	float temperaturaC;
	float temp;
	int i=0;
	int cont=0;
	
		

	
	
	//Leitura do ficheiro 
	
	fTemperaturasF =fopen ("temperaturas_F.txt","r");
	while (fscanf(fTemperaturasF,"%s", cidades[i].nome)!=EOF)
		
	{
		
		fscanf(fTemperaturasF,"%f",&cidades[i].tempf);
		cidades[i].tempc = (cidades[i].tempf-32)/1.8; 
		
		i++;
		
	}
	cont =i;
	fclose(fTemperaturasF);
	i=0;
	
	//Algoritmo
	fTemperaturasC=fopen("temperaturas_C.txt","w");
	while(i<cont)
	{
		fprintf(fTemperaturasC, "Nome da cidade:%s \nTemperatura em F�:%.1f F� \nTemperatura em C�:%.1f C�\n_____________________________________\n",cidades[i].nome,cidades[i].tempf,cidades[i].tempc);
		i++;
	}
	printf("Ficheiro de Cidades e suas Temperaturas criado");

} 
