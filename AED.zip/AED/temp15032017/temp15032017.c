#include <stdio.h>

int main()
{
	//Dleclara��o de variaveis
	
	FILE*fTemperaturas;
	FILE*fAnaliseTemperaturas;
	float v_temperaturas[31];
	float media;
	float temp;
	float soma= 0;
	float maxtemp=0;
	float mintemp=0;
	int i=0;
	int j=0;

	
	
	//Leitura do ficheiro
	
	fTemperaturas =fopen ("temperaturas.txt","r");
	while (fscanf(fTemperaturas,"%f",&temp)!=EOF)
		
	{
		v_temperaturas[i]=temp;
		i++;
		printf("%d- %.1f\n",i,temp);	
	}
	fclose(fTemperaturas);
	
	i=0;
	while(i<=30)
	{
		soma= soma+v_temperaturas[i];
		i++;
	}
	media=soma/31;

	//Algoritmo 
	i=0;
	mintemp=v_temperaturas[0];
	while(i<=30)
	{

		
		if (v_temperaturas[i]<mintemp)
		{
			mintemp=v_temperaturas[i];
		}
			
		if (v_temperaturas[i]>maxtemp)
		{
			maxtemp=v_temperaturas[i];
		}
			
		if (media<v_temperaturas[i])
		{
			j++;
		}
		i++;	
	}
	
	//apresenta��o de resultados 
	fAnaliseTemperaturas =fopen ("Analise_temperaturas.txt","w");
	fprintf(fAnaliseTemperaturas,"Media:%.1f\nTemperatura Minima:%.1f\nTemperatura Maxima:%.1f\nN� de Temperaturas a cima da Media:%d",media,mintemp,maxtemp,j);
	fclose(fAnaliseTemperaturas);
	printf("\nFicheiro com a anlise de temperaturas foi criado na pasta local");
	
	
	return 0;
	
	
	
	
	
	

}
