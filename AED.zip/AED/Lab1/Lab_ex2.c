#include <stdio.h>
int main (void)
{
	int centenas;
	int dezenas;
	int unidades;
	int numero;
	
	centenas = 3;
	dezenas =5;
	unidades =2;
	
	printf("Este programa congrega, num numero, %d centenas, %d dezenas, %d unidades\n", centenas , dezenas, unidades);
	numero  = centenas*100+dezenas*10+unidades;
	
	printf("Resultado: %d\n",numero);
	return 0;
}
