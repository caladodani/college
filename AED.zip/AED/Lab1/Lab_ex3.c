#include <stdio.h>
int main (void)
{
	printf("Introduzir as centenas:\n");
	int centenas;
	scanf("%d",&centenas);
	
	printf("Introduzir as dezenas:\n");
	int dezenas;
	scanf("%d",&dezenas);
	
	
	printf("Introduzir as unidades:\n");
	int unidades;
	scanf("%d",&unidades);
	
	int numero;
	
	
	



	
	printf("Este programa congrega, num numero, %d centenas, %d dezenas e %d unidades\n", centenas, dezenas,unidades);
	
	numero = centenas*100+dezenas*10+unidades;
	
	printf("Resultado: %d\n", numero);
	return 0;
}
