#include <stdio.h>
int main (void)
{
	int teste_1;
	printf("Introduzir nota de teste 1:\n");
	scanf("%d",&teste_1);
	
	int teste_2;
	printf("Introduzir nota de teste 2:\n");
	scanf("%d",&teste_2);
	
	float trabalhos;
	printf("Introduzir media dos trabalhos:\n");
	scanf("%f",&trabalhos);
	
	float nota;
	int peso_testes;
	int peso_trabalhos;
	
	peso_testes = 3;
	peso_trabalhos = 2.5;
	nota =((teste_1+ teste_2)/((2*peso_testes)+(trabalhos*peso_trabalhos))/(peso_testes+peso_trabalhos));
	printf("A nota : %f",nota);
	return 0;
	
}
