#include <stdio.h>
int main (void)
{
	int numero;
	printf("Introduzir numero:\n");
	scanf("%d",&numero);
	
	int milhares;
	int centenas;
	int dezenas;
	int unidades;
	if (numero > 9999)
		{
			printf("Numero Invalido");
			return 0;
			
		}
	else
		{
			milhares= numero/1000;
			centenas=(numero - (milhares*1000))/100;
			dezenas = (numero -(centenas*100)-(milhares*1000))/10;
			unidades= (numero - (dezenas*10)-(centenas*100)-(milhares*1000));
			printf("Milhares: %d \n",milhares);
			printf("centenas: %d \n",centenas);
			printf("Dezenas: %d \n",dezenas);
			printf("Unidades: %d \n",unidades);
			return 0;
			
		}
}
