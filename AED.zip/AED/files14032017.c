#include <stdio.h>

int main () {
	//Delara��o de variaveis
	FILE*fContactos;
	int nrTlf;
	int mes;
	int ano;
	int dia;
	int i;
	char PrimeiroNome[50];
	char SegundoNome[50];
	int opcao;
	
	//Leitura de dados
	fContactos = fopen ("contactos.txt","r");
	while (fscanf(fContactos,"%s",PrimeiroNome)!=EOF)
	{
		
		fscanf(fContactos, "%s%d%d%d%d",SegundoNome,&nrTlf,&dia,&mes,&ano);
		i++;
		printf("%d- %s %s %d %d %d %d\n\n",i,PrimeiroNome,SegundoNome,nrTlf,dia,mes,ano);
			
	}
	opcao =1;
	printf("Escreva 1 para acrescentar ou 0 para sair:");
	scanf("%d", &opcao);
	while (opcao != 0)
	{
		
		printf("Primeiro nome:\n");
		fscanf(stdin,"%s",PrimeiroNome);
		printf("Sengundo Nome:\n");
		fscanf(stdin,"%s",SegundoNome);
		printf("Numero de telefone:\n");
		fscanf(stdin,"%d",&nrTlf);
		printf("Dia, mes e ano de nascimento\n");
		fscanf(stdin,"%d %d %d",&dia, &mes, &ano);
		fprintf(fContactos,"%s %s %d %d %d %d\n", PrimeiroNome, SegundoNome, nrTlf, dia, mes,ano);
		printf("Escreva 1 para acrescentar ou 0 para sair:");
		scanf("%d", &opcao);
		
	}
	if (opcao!=1)
	{
		while (fscanf(fContactos,"%s",PrimeiroNome)!=EOF)
		{
			
			fscanf(fContactos, "%s%d%d%d%d",SegundoNome,&nrTlf,&dia,&mes,&ano);
			i++;
			printf("%d- %s %s %d %d %d %d\n\n",i,PrimeiroNome,SegundoNome,nrTlf,dia,mes,ano);
				
		}
		printf("Encerrando\n");
		fclose (fContactos);
	}
		
	
	//algoritmo

	
	//apresenta��o de resultados
	
	printf("Foram lidos %d contactos\n",i);

}
