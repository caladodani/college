#include <stdio.h> 
#include <time.h> 

main()
{
	FILE* fp;
	int i, aux;
	
	fp = fopen("numeros.txt", "w");

	for(i=0; i<500; i++)
	{
		aux = rand()%101;
		fprintf(fp, "%d %d\n",i, aux);
	}
	fclose(fp);
}

