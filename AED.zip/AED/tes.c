#include <stdio.h>

int main (void)
{

	float res;
	res=1;
	while(res!=-1)	
	{
		int a;
		printf ("\na=?\n");
		scanf("%d",&a);
		
		if(a==-1)
			res=-1;
		
		int b;
		printf("\nb=?\n");
		scanf("%d",&b);
		switch(a,b)
		{
			case b:
				printf("igual");
				break;
			
			case >b :
				printf("maior");
				break;
		}
		
		
	//	if (a==b)
	//		printf("igual");
	//	if (a>b)
	//		printf("maior");
		if (a<b)
			printf("menor");
			
		if ((a%2)==0)
			printf ("\na e par");
		if(!((a%2)==0))
			printf("\nb e impar");
	
		if ((b%2)==0)
			printf ("\nb e par \n");			
		if(!((b%2)==0))
			printf("\nb e impar \n");	

		 
	}
	
	printf("fim de programa");
	return 0;
		
		
	
}
