#include <stdio.h>

int main (void)
{
	// Atribui��o de Variaveis
	int num;
	int fact;
	// Leitura de Valores
	printf("Introduza um numero: \n");
	scanf("%d",&num);
	
	//Algoritmio
	fact =1;
	while (num >0)
	{
			fact = num * (fact);
			num--;
	}
	//Apresenta��o de resultas
	
	printf("O factorial e : \n");
	printf("%d",fact);
}
	
	
