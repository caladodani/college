#include <stdio.h>
int main()
{
	int pot;
	printf("Introduza o valor da potencia do motor a construir: ");
	scanf("%d",&pot);
	if (pot < 1)
		printf("Mensagem de erro - Nao e possivel construir o motor.\n");
	else
		if ( (1<= pot) && (pot<5))
			printf("Accao a executar - PW1.\n");
		else
			if ( (5<= pot) && (pot<20))
				printf("Accao a executar - PW2.\n");
			else
				if ( (20<= pot )&&(pot <100))
					printf("Accao a executar - PW3.\n");
				else
					printf("Mensagem de erro - Nao e possivel construir o motor.\n");
			 		
	return 0;
}

