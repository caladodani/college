#include <stdio.h>
int main()
{
	int notaTeste1 = 15, notaTeste2 = 15, notaTeste3 = 17;
	printf("Nota do primeiro teste \n"), scanf("%d",&notaTeste1);
	printf("Nota do segundo teste \n"), scanf("%d",&notaTeste2);
	printf("Nota do terceiro teste \n"), scanf("%d",&notaTeste3);
	double media;
	media = (notaTeste1 + notaTeste2 + notaTeste3)/3.0;
	printf("Nota final : %3.2f valores\n", media);
	return 0;
}

