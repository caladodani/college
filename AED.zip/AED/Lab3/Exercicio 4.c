#include <stdio.h>
int main()
{
	char c = 'r';
	//tive que declarar a variavel y pois n�o estava declarada 
	int y = 2;
	short j = 127;
	int k = 32767;
	printf("c= %c\n", c);
	c=c+1;
	printf("c= %c\n", c);
	c=c+1;
	printf("c= %c\n", c);
	printf("j= %d\n", j);
	j=j-1;
	printf("j= %d\n", j);
	j++;
	printf("j= %d\n", j);
	printf("k= %d\n", k);
	k -=4;
	printf("k= %d\n", k);
	k = k+5;
	printf("k= %d\n", k);
	printf("Valores finais:\n\tc = %c\n\tj = %d",c,j);
	printf("\n\tk = %d\n\n", k);
	printf("y= %d\n", y);
	return 0;
}
