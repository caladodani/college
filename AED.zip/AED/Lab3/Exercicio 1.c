#include <stdio.h>
int main()
{
	int valor= 90000;
	printf("Um int int : %d",valor);
	return 0;
}
