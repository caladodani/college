#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
	int i;
	int a;
	int b;
	printf("Introduza a:\n"), scanf("%d",&a);
	printf("Introduza b:\n"), scanf("%d",&b);
	
	// inicializar a semente do gerador de n�meros aleat�rios
	srand( (unsigned)time(NULL) );
	
	// mostrar o intervalo dos n�meros aleat�rios gerados por rand
	printf("intervalo da rand: [%d,%d]\n", a,b);
	
	// imprimir 10 n�meros aleat�rios
	i= 1;
	do  
	{
		printf("Numero %d: %d\n",i, rand()%(b-a+1)+a);
		i++;
	}while (i<=10);

	return 0;
}
