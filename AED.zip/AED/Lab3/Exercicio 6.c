#include <stdio.h>
#include <stdlib.h>
int main()
{
	int a=10, b=20;
	if (a>b)
	{
		printf("a primeira condicao");
		printf(" foi verdadeira\n");
	}	
	else
		printf("a primeira condicao foi falsa\n");
	return 0;
} 
