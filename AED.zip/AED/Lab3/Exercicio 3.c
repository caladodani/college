#include <stdio.h>
int main()
{
	char ch = 'Z';
	printf("Um char : %d",ch);
	return 0;
}

