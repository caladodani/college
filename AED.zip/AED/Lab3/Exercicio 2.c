#include <stdio.h>
int main()
{
	float valor= 900.25;
	printf("Um float : %e",valor);
	return 0;
}
