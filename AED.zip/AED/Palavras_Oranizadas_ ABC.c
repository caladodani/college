#include <stdio.h>

int main (void)
{
	//Declara��o de variaveis
	int i;
	int j;
	int conta=0;
	int opcao;
	char Nome_1[100];
	char Nome_2[100];
	
	//Leitura de Dados 
	
	printf("Introduza o 1� Nome \n");
	scanf("%s",Nome_1);
	
	printf("Introduza o 2� Nome \n");
	scanf("%s",Nome_2);
	
	
	//Algoritmo
	
	while (!(Nome_1[i]=='\0'))
	{
		i++;
		
	}
	while (!(Nome_2[j]=='\0'))
	{
		j++;
		
	}
	

	while ((!(Nome_1[conta]=='\0'))&&(!(Nome_2[conta]=='\0')))
	{
		if (Nome_1[conta] > Nome_2[conta])
			{
				opcao =1;
				return 0;	
			}
			
		if (Nome_1[conta] < Nome_2[conta])
		{
			opcao=2;
			return 0;	
		}
		
		

		conta++;
		
	}
	if (Nome_1[conta] == Nome_2[conta])
	{
		opcao=3;
			
	}
	if (((Nome_1[conta]=='\0') )|| (Nome_2[conta]=='\0'))
	{
		if (i< j)
			opcao = 4;
		if (i> j)
			opcao = 5;
	}
	
	
	//Apresenta��o de Resultados
	
	switch (opcao)
	{
		case 1:printf("O nome %s e anterior ao nome %s",Nome_2,Nome_1);
			break;
		case 2:printf("O nome %s e anterior ao nome %s",Nome_1, Nome_2);
			break;
		case 3:printf("O nome %s e igual ao nome %s",Nome_1, Nome_2);
			break;
		case 4:printf("O nome %s e anterior ao nome %s",Nome_1, Nome_2);
			break;
		case 5:printf("O nome %s e anterior ao nome %s",Nome_2, Nome_1);
			break;
	}	
	return 0;
}
