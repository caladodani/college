eliminate(Xs,N,Rs) :-
  N > 0 ,
  eliminate(Xs,1,N,Rs).

eliminate( []     , _ , _ , [] ) .
eliminate( [X|Xs] , P , N , R1 ) :-
  ( 0 = P mod N),
  P1 is P+1 ,
  eliminate(Xs,P1,N,R1).
eliminate( [X|Xs] , P , N , [X,R1] ) :-
  (0 <> P mod N), 
  P1 is P+1 ,
  eliminate(Xs,P1,N,R1).
