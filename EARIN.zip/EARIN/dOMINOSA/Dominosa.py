import random
import sys
import time
sys.setrecursionlimit(1000000000)
t=int(input("Give the Number of lines? - "))
tPlus1 = t+1 
table = [[0 for x in range(tPlus1)] for y in range(t)]
Checked = [[0 for x in range(tPlus1)] for y in range(t)]
Directions = [[0 for x in range(tPlus1)] for y in range(t)]

global lst
lst=[]
global pieces
pieces=[]
node=0

g=0
print(tPlus1,"*",t)
ale=str(input("Should the method be random? (n) for no --"))
for i in range(t):
    if g==10:
        break
    print("line",i+1)
    j=0
    for j in range(tPlus1):
        print("element",j+1)
        g=int(input("- "))
        if g == 10:
            if t ==3:
                table[0][0]=0
                table[0][1]=2
                table[0][2]=2
                table[0][3]=1

                table[1][0]=0
                table[1][1]=1
                table[1][2]=2
                table[1][3]=1

                table[2][0]=0
                table[2][1]=1
                table[2][2]=0
                table[2][3]=2
            if t ==4:
                table[0][0]=3
                table[0][1]=3
                table[0][2]=2
                table[0][3]=3
                table[0][4]=3

                table[1][0]=3
                table[1][1]=2
                table[1][2]=2
                table[1][3]=2
                table[1][4]=1

                table[2][0]=0
                table[2][1]=0
                table[2][2]=0
                table[2][3]=0
                table[2][4]=0

                table[3][0]=1
                table[3][1]=2
                table[3][2]=1
                table[3][3]=1
                table[3][4]=1
            if t==5:
                table[0][0]=4
                table[0][1]=4
                table[0][2]=3
                table[0][3]=4
                table[0][4]=0
                table[0][5]=2

                table[1][0]=1
                table[1][1]=4
                table[1][2]=0
                table[1][3]=4
                table[1][4]=0
                table[1][5]=4

                table[2][0]=2
                table[2][1]=3
                table[2][2]=1
                table[2][3]=3
                table[2][4]=3
                table[2][5]=1

                table[3][0]=3
                table[3][1]=2
                table[3][2]=0
                table[3][3]=2
                table[3][4]=3
                table[4][5]=0

                table[4][0]=0
                table[4][1]=2
                table[4][2]=1
                table[4][3]=1
                table[4][4]=2
                table[4][5]=1
            break
        else:
            table[i][j]=g
            

for j in range(len(table)):
    print(table[j])



    
c=str(input("ok?"))    
print("")
def piececheck(n1,n2):
    p=n1+n2
    
    if n1 == 0 and n2 ==0:
        p=0
    if (n1 == 0 and n2 ==1)or(n1 == 1 and n2 ==0):
        p=1
    if n1 == 1 and n2 ==1:
        p=11
    if (n1 == 0 and n2 ==2)or(n1 == 2 and n2 ==0):
        p=2
    if (n1 == 1 and n2 ==2)or(n1 == 2 and n2 ==1):
        p=12
    if n1 == 2 and n2 ==2:
        p=22
    if (n1 == 0 and n2 ==3)or(n1 == 3 and n2 ==0):
        p=3
    if (n1 == 1 and n2 ==3)or(n1 == 3 and n2 ==1):
        p=13
    if (n1 == 2 and n2 ==3)or(n1 == 3 and n2 ==2):
        p=23
    if n1 == 3 and n2 ==3:
        p=33
    if (n1 == 0 and n2 ==4)or(n1 == 4 and n2 ==0):
        p=4
    if (n1 == 1 and n2 ==4)or(n1 == 4 and n2 ==1):
        p=14
    if (n1 == 2 and n2 ==4)or(n1 == 4 and n2 ==2):
        p=24
    if (n1 == 3 and n2 ==4)or(n1 == 4 and n2 ==3):
        p=34
    if n1 == 4 and n2 ==4:
        p=44
    if (n1 == 0 and n2 ==5)or(n1 == 5 and n2 ==0):
        p=5
    if (n1 == 1 and n2 ==4)or(n1 == 5 and n2 ==1):
        p=15
    if (n1 == 2 and n2 ==4)or(n1 == 5 and n2 ==2):
        p=25
    if (n1 == 3 and n2 ==5)or(n1 == 5 and n2 ==3):
        p=35
    if (n1 == 4 and n2 ==5)or(n1 == 5 and n2 ==4):
        p=45
    if n1 == 5 and n2 ==5:
        p=55
    if (n1 == 0 and n2 ==6)or(n1 == 6 and n2 ==0):
        p=6
    if (n1 == 1 and n2 ==6)or(n1 == 6 and n2 ==1):
        p=16
    if (n1 == 2 and n2 ==6)or(n1 == 6 and n2 ==2):
        p=26
    if (n1 == 3 and n2 ==6)or(n1 == 6 and n2 ==3):
        p=36
    if (n1 == 4 and n2 ==6)or(n1 == 6 and n2 ==4):
        p=46
    if (n1 == 45 and n2 ==6)or(n1 == 6 and n2 ==5):
        p=56
    if n1 == 6 and n2 ==6:
        p=66
    return p


def AvP(n1,n2,Lista):
    T=piececheck(n1,n2)
    a=True
    existe=False
    if len(Lista)==0:
          Lista=[T]+Lista            
    else:
        for i in range(len(Lista)):

            if Lista[i]==T:
                print('Already Selected')
                existe=True
                a=False

        if existe==False:
                Lista=Lista+[T]
    global lst
    lst = Lista
    return a

def Remover():
    global lst
    lst = lst[:-1]
def CellAv(x,y,p):
    global Checked
    if p==0:
        Checked[x][y] ='a'
    if p==1:
        Checked[x][y] = 'b'
    if p==2:
        Checked[x][y] ='c'
    if p==3:
        Checked[x][y] = 'd'
    if p==4:
        Checked[x][y] ='e'
    if p==5:
        Checked[x][y] = 'f'
    if p==6:
        Checked[x][y] = 'g'
    if p==7:
        Checked[x][y] = 'h'
    if p==8:
        Checked[x][y] = 'i'
    if p==9:
        Checked[x][y] = 'J'
    if p==10:
        Checked[x][y] = 'k'
    if p==11:
        Checked[x][y] = 'l'
    if p==12:
        Checked[x][y] = 'm'

    
def ChCellAv(x,y):
    global Checked
    if Checked[x][y]==0:
        return True
    else:
        return False
def RemCelAv(x,y):
    global Checked
    Checked[x][y] = 0
    
def AdPiece(x,y,h,v):
    global pieces
    
    pieces=pieces+[[x,y,h,v]]
    
def RemPiece():
    global pieces
    pieces = pieces[:-1]

def LastPiece():
    global pieces
    #i = len(pieces)-1
    
    return pieces[-1]

def LastDir(h,v,d):
    global Directions
    Directions[h][v]= d
def RemDir(h,v):
    global Directions
    Directions[h][v]=0

node=node +1  
def solve(h,v,i,op):
    global peices
    global Directions
    global node

    
    if len(lst)< (t*tPlus1)/2:
        back=0
        if (h == t-1  and v == t)or (h<0 or h==t):
            print("Unexpected Error..")
            print("Starting Over...")
            global Checked
            Checked = [[0 for x in range(tPlus1)] for y in range(t)]
            pieces = []
            Directions = []
            solve(0,0,0,0)
            return 1
            
        print("")
        print("Cell",h,"/",v)
        if not ChCellAv(h,v):
            print("Busy...")
            if v==t:
                solve(h+1,0,i,0)
                return 1
            else:
                solve(h,v+1,i,0)
                return 1
        
        rd=random.randint(0,1)
        if t ==3 or ale=="n":
            rd=1
        direc = rd
        
#verification if the piece will place inside of bounds
        if v==tPlus1-1:
            direc = 0
        if v!=tPlus1-1 and not ChCellAv(h,v+1):
            direc = 0
        if h==t-1:
            direc = 1
        if h!=t-1 and not ChCellAv(h+1,v):
            direc = 1
        if op==1:
            direc=0
#Removal of direction history
        if op==5:
            RemDir(h,v)
            if v==t:
                RemDir(h+1,0)
            if h==t-1:
                RemDir(h,v+1)
    
            if v != t and h!=t-1:
                    RemDir(h,v+1)
                    if v == t-2:
                        RemDir(h,v+2)
                        
                    RemDir(h+1,0)
#after backtracking checking previous directions
        if Directions[h][v]=="right":
            direc =0
#if last direction was down go right to backtracking
        if Directions[h][v]=="down":
            
            node=node +1
            
            direc=2
            print("Backing up...")
            Remover()
            RemCelAv(LastPiece()[0],LastPiece()[1])
            RemCelAv(LastPiece()[2],LastPiece()[3])
            r=LastPiece()[0]
            p=LastPiece()[1]
            RemPiece()
            if r ==0 and p==0:
                node=node +1
                print("MAIN ROOT")
                Checked = [[0 for x in range(tPlus1)] for y in range(t)]
                pieces = []
                Directions=[[0 for x in range(tPlus1)] for y in range(t)]
                solve(0,0,0,1)
                
            else:
                solve(LastPiece()[0],LastPiece()[1],i-1,1)
            return 1
            



#Placing the piece horizontally
        if direc==1 and ChCellAv(h,v+1):
            a=table[h][v]
            b=table[h][v+1]
            print("Trying Direction:",direc)
            if AvP(a,b,lst):
                print("Direction Selected:",direc)
                LastDir(h,v,"right")

                if v+2<=tPlus1-1:
                    
                    print("")
                    print(table[h][v],"-",table[h][v+1])
                    
                    node=node +1
                    
                    print("-----------------------------------")
                    CellAv(h,v,a+b)
                    CellAv(h,v+1,a+b)
                    AdPiece(h,v,h,v+1)
                    solve(h,v+2,i+1,5)
                else:
                    CellAv(h,v,a+b)
                    CellAv(h,v+1,a+b)
                    AdPiece(h,v,h,v+1)
                    print("")
                    print(table[h][v],"-",table[h][v+1])
                    
                    node=node +1
                    
                    print("-----------------------------------")
                    solve(h+1,0,i+1,5)
            else:
                direc=0
#cheking if piece can be placed vertically              
        if direc==0 and h==t-1:
            back=1
#placing the piece vertically    
        if direc==0 and h<t-1:
            a=table[h][v]
            b=table[h+1][v]
            print("Trying Direction:",direc)
            if AvP(a,b,lst):
                print("Direction Selected:",direc)
                LastDir(h,v,"down")
                if v+1<=tPlus1-1:

                    print("")
                    print(table[h][v],"-",table[h+1][v])
                    
                    node=node +1
                    
                    print("-----------------------------------")
                    CellAv(h,v,a+b)
                    CellAv(h+1,v,a+b)
                    
                    AdPiece(h,v,h+1,v)
                    solve(h,v+1,i+1,5)
                    
                else:
                    CellAv(h,v,a+b)
                    CellAv(h+1,v,a+b)
                    AdPiece(h,v,h+1,v)

                    print("")
                    print(table[h][v],"-",table[h+1][v])
                    
                    node=node +1
                    
                    print("-----------------------------------")
                    
                    solve(h+1,0,i+1,5)
            else:
                back = 1
        if back==1:
            node=node +1
            
            print("Backing up...")
            Remover()
            RemCelAv(LastPiece()[0],LastPiece()[1])
            RemCelAv(LastPiece()[2],LastPiece()[3])
            r=LastPiece()[0]
            p=LastPiece()[1]
            RemPiece()
            solve(r,p,i-1,1)
    else:
        if Checked[t-1][t]==0:
            print("Unexpected Error..")
            print("Starting Over...")
            Checked = [[0 for x in range(tPlus1)] for y in range(t)]
            pieces = []
            solve(0,0,0,0)
            Directions=[]
            return 
        print("Solved!!")
        for i in range(len(Checked)):
            print(Checked[i])

        print("*******************************")
        print("*******************************")
        print("*******************************")
        

solve(0,0,0,0)
timer= time.clock()
print("nodes visited",node)
times= time.clock()
times=times-timer
print("Time taken : ",times*1000,"ms")
c=str(input(""))
