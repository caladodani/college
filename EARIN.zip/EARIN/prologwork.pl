eliminate(Xs,N,Rs) :-
  N > 0 ,
  eliminate(Xs,1,N,Rs).

eliminate( []     , _ , _ , [] ) .
eliminate( [X|Xs] , P , N , Rs ) :-
  ( 0 =:= P mod N -> R1 = Rs ; [X|R1] = Rs ) ,
  P1 is P+1 ,
  eliminate(Xs,P1,N,R1).
