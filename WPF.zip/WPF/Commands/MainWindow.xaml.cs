﻿using System.Diagnostics;
using System.Windows;

namespace Commands
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Student student;

        public MainWindow()
        {
            InitializeComponent();
            student = new Student("Kowalski", "Jan", 12345, "4I3");
            DataContext = student;
        }

        private void readButton_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Student");
            Debug.WriteLine( "\tname: " + student.Name + " (control: " + nameTextBox.Text + ")" );
            Debug.WriteLine("\tsurname: " + student.Surname + " (control:" + surnameTextBox.Text + ")");
            Debug.WriteLine("\tindex: " + student.Index + " (control:" + indexTextBox.Text + ")");
            Debug.WriteLine("\tgroup: " + student.Group + " (control:" + groupTextBox.Text + ")");
        }
    }
}
