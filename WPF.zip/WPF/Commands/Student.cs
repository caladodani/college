﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Commands
{
    public class Student : INotifyPropertyChanged
    {

        private SetCommand setCommand = new SetCommand();

        public SetCommand SetCommand1
        {
            get
            {
                return setCommand;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public Student( string surname, string name, int index, string group)
        {
            Surname = surname;
            Name = name;
            Index = index;
            Group = group;
        }

        private string surname;
        public string Surname
        {
            get
            {
                return surname; 
            }
            set
            {
                surname = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Surname"));
            }
        }


        string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Name"));
            }
        }

        int index;
        public int Index
        {
            get
            {
                return index;
            }
            set
            {
                index = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Index"));
            }
        }

        string group;
        public string Group
        {
            get
            {
                return group;
            }
            set
            {
                group = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Group"));
            }
        }
    }
}
