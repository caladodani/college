﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBinding
{
    public class Student : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public Student( string surname, string name, int index, string group)
        {
            Surname = surname;
            Name = name;
            Index = index;
            Group = group;
        }

        private string surname;
        public string Surname
        {
            get
            {
                return surname; 
            }
            set
            {
                surname = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Surname"));
            }
        }


        string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Name"));
            }
        }

        public int Index
        { get; set; }
        public string Group
        { get; set; }
    }
}
