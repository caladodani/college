﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBinding2
{
    public class Student
    {
        public Student( string surname, string name, int index, string group)
        {
            Surname = surname;
            Name = name;
            Index = index;
            Group = group;
        }

        public string Surname
        { get; set; }

        public string Name
        { get; set; }

        public int Index
        { get; set; }

        public string Group
        { get; set; }
    }
}
