﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CollectionFiltering
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Student> students;

        public MainWindow()
        {
            InitializeComponent();
            students = new List<Student>();
            students.Add(new Student("Adam", "Nowak", 12345, "3I2"));
            students.Add(new Student("Jan", "Nowak", 12346, "3I3"));
            students.Add(new Student("Adam", "Kowalski", 12347, "3I1"));
            students.Add(new Student("Jan", "Kowalski", 12348, "3I1"));

            collectionViewSource = new CollectionViewSource();
            collectionViewSource.Source = students;
            studentsListView.ItemsSource = collectionViewSource.View;
        }

        private CollectionViewSource collectionViewSource;

        private bool Filter( object o )
        {
            Student student = o as Student;
            if (student == null)
                return false;
            if (student.Index >= 12347)
                return true;
            else
                return false;
        }

        private void studentsListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            collectionViewSource.View.Filter = Filter;
        }
    }
}
