﻿using System.Windows;
using System.Windows.Controls;

namespace DependencyPropertyExample
{
    public class MyButton : Button
    {
        #region MyTextProperty
        public static readonly DependencyProperty MyTextProperty = DependencyProperty.Register("MyText", typeof(string), typeof(MyButton),
              new FrameworkPropertyMetadata("MyButton2.MyText default value", FrameworkPropertyMetadataOptions.Inherits));

        public string MyText
        {
            get { return GetValue(MyTextProperty).ToString(); }
            set { SetValue(MyTextProperty, value); }
        }
        #endregion

        #region MyTextSharedProperty
        public static readonly DependencyProperty MyTextSharedProperty = MyGrid1.MyTextSharedProperty.AddOwner(typeof(MyButton));

        public string MyTextShared
        {
            get { return GetValue(MyTextSharedProperty).ToString(); }
            set { SetValue(MyTextSharedProperty, value); }
        }
        #endregion

        #region MyTextInheritedProperty
        public static readonly DependencyProperty MyTextInheritedProperty = MyGrid1.MyTextInheritedProperty.AddOwner(typeof(MyButton), new FrameworkPropertyMetadata("MyButton.MyTextInherited default value", FrameworkPropertyMetadataOptions.Inherits));

        public string MyTextInherited
        {
            get { return GetValue(MyTextInheritedProperty).ToString(); }
            set { SetValue(MyTextInheritedProperty, value); }
        }
        #endregion
    }
}
