﻿using System.Windows;
using System.Windows.Controls;

namespace DependencyPropertyExample
{
    public class MyGrid1 : Grid
    {
        #region MyTextProperty
        public static readonly DependencyProperty MyTextProperty = DependencyProperty.Register("MyText", typeof(string), typeof(MyGrid1),
              new FrameworkPropertyMetadata("MyGrid1.MyText default value"));

        public string MyText
        {
            get { return GetValue(MyTextProperty).ToString(); }
            set { SetValue(MyTextProperty, value); }
        }
        #endregion

        #region MyTextReadonlyProperty
        private static readonly DependencyPropertyKey MyTextReadOnlyPropertyKey = DependencyProperty.RegisterReadOnly("MyTextReadOnly", typeof(string), typeof(MyGrid1),
              new FrameworkPropertyMetadata("MyGrid1.MyTextReadOnly default value"));
        private static readonly DependencyProperty MyTextReadOnlyProperty = MyTextReadOnlyPropertyKey.DependencyProperty;

        public string MyTextReadonly
        {
            get { return GetValue(MyTextReadOnlyProperty).ToString(); }
            set { SetValue(MyTextReadOnlyPropertyKey, value); }
        }
        #endregion

        #region MyTextAttachedProperty
        public static readonly DependencyProperty MyTextAttachedProperty = DependencyProperty.RegisterAttached("MyTextAttached", typeof(string), typeof(MyGrid1),
              new FrameworkPropertyMetadata("MyGrid1.MyTextAttached default value"));

        [AttachedPropertyBrowsableForChildren(IncludeDescendants = true)]
        public static string GetMyTextAttached( UIElement element)
        {
            return (string)element.GetValue(MyTextAttachedProperty);
        }

        public static void SetMyTextAttached( UIElement element, string value)
        {
            element.SetValue(MyTextAttachedProperty, value);
        }
        #endregion

        #region MyTextSharedProperty
        public static readonly DependencyProperty MyTextSharedProperty = DependencyProperty.Register("MyTextShared", typeof(string), typeof(MyGrid1),
              new FrameworkPropertyMetadata("MyGrid1.MyTextShared default value"));

        public string MyTextShared
        {
            get { return GetValue(MyTextSharedProperty).ToString(); }
            set { SetValue(MyTextSharedProperty, value); }
        }
        #endregion

        #region MyTextInheritedProperty
        public static readonly DependencyProperty MyTextInheritedProperty = DependencyProperty.Register("MyTextInherited", typeof(string), typeof(MyGrid1),
              new FrameworkPropertyMetadata("MyGrid1.MyTextInherited default value", FrameworkPropertyMetadataOptions.Inherits));

        public string MyTextInherited
        {
            get { return GetValue(MyTextInheritedProperty).ToString(); }
            set { SetValue(MyTextInheritedProperty, value); }
        }
        #endregion
    }
}
