﻿using System.Diagnostics;
using System.Windows;

namespace DependencyPropertyExample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void myButton1_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("MyText");
            Debug.WriteLine("\tgrid1   " + myGrid1.MyText);
            Debug.WriteLine("\tgrid2_a " + myGrid2_a.MyText);
            Debug.WriteLine("\tgrid2_b " + myGrid2_b.MyText);
            Debug.WriteLine("\tbutton1 " + myButton1.MyText);
            Debug.WriteLine("\tbutton  " + myButton2.MyText);


            Debug.WriteLine("MyTextShared");
            Debug.WriteLine("\tgrid1   " + myGrid1.MyTextShared);
            Debug.WriteLine("\tgrid2_a " + myGrid2_a.MyTextShared);
            Debug.WriteLine("\tgrid2_b " + myGrid2_b.MyTextShared);
            Debug.WriteLine("\tbutton1 " + myButton1.MyTextShared);
            Debug.WriteLine("\tbutton  " + myButton2.MyTextShared);

            Debug.WriteLine("MyTextInherited");
            Debug.WriteLine("\tgrid1   " + myGrid1.MyTextInherited);
            Debug.WriteLine("\tgrid2_a " + myGrid2_a.MyTextInherited);
            Debug.WriteLine("\tgrid2_b " + myGrid2_b.MyTextInherited);
            Debug.WriteLine("\tbutton1 " + myButton1.MyTextInherited);
            Debug.WriteLine("\tbutton  " + myButton2.MyTextInherited);

            Debug.WriteLine("MyTextAttached");
            Debug.WriteLine("\tgrid1   " + MyGrid1.GetMyTextAttached(myGrid1));
            Debug.WriteLine("\tgrid2_a " + MyGrid1.GetMyTextAttached(myGrid2_a));
            Debug.WriteLine("\tgrid2_b " + MyGrid1.GetMyTextAttached(myGrid2_b));
            Debug.WriteLine("\tbutton1 " + MyGrid1.GetMyTextAttached(myButton1));
            Debug.WriteLine("\tbutton  " + MyGrid1.GetMyTextAttached(myButton2));

        }
    }
}
