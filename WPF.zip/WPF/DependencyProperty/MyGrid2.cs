﻿using System.Windows;
using System.Windows.Controls;

namespace DependencyPropertyExample
{
    public class MyGrid2 : Grid
    {
        #region MyTextProperty
        public static readonly DependencyProperty MyTextProperty = DependencyProperty.Register("MyText", typeof(string), typeof(MyGrid2),
              new FrameworkPropertyMetadata("MyGrid2.MyText default value", FrameworkPropertyMetadataOptions.Inherits));

        public string MyText
        {
            get { return GetValue(MyTextProperty).ToString(); }
            set { SetValue(MyTextProperty, value); }
        }
        #endregion

        #region MyTextSharedProperty
        public static readonly DependencyProperty MyTextSharedProperty = MyGrid1.MyTextSharedProperty.AddOwner(typeof(MyGrid2));

        public string MyTextShared
        {
            get { return GetValue(MyTextSharedProperty).ToString(); }
            set { SetValue(MyTextSharedProperty, value); }
        }
        #endregion

        #region MyTextInheritedProperty
        public static readonly DependencyProperty MyTextInheritedProperty = MyGrid1.MyTextInheritedProperty.AddOwner(typeof(MyGrid2), new FrameworkPropertyMetadata("MyGrid2.MyTextInherited default value", FrameworkPropertyMetadataOptions.Inherits));

        public string MyTextInherited
        {
            get { return GetValue(MyTextInheritedProperty).ToString(); }
            set { SetValue(MyTextInheritedProperty, value); }
        }
        #endregion
    }
}
