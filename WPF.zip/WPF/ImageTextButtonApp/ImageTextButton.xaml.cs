﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ImageTextButtonApp
{
    /// <summary>
    /// Interaction logic for ImageTextButton.xaml
    /// </summary>
    public partial class ImageTextButton : UserControl
    {
        public ImageTextButton()
        {
            InitializeComponent();
        }

        #region TextProperty
        public static readonly DependencyProperty TextProperty = DependencyProperty.Register("Text", typeof(String), typeof(ImageTextButton), 
            new FrameworkPropertyMetadata(string.Empty, OnTextPropertyChanged, OnCoerceTextProperty));

        public string Text
        {
            get { return GetValue(TextProperty).ToString(); }
            set { SetValue(TextProperty, value); }
        }

        private static void OnTextPropertyChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
        {
            ImageTextButton control = source as ImageTextButton;
            string text = (string)e.NewValue;
            control.IsText = text.Length > 0;
        }

        private static object OnCoerceTextProperty(DependencyObject sender, object data)
        {
            if (((string)data).Length > 5)
                return ((string)data).Substring(0, 5);
            else
                return data;
        }

        #endregion

        #region ImageSourceProperty
        public static readonly DependencyProperty ImageSourceProperty = DependencyProperty.Register("ImageSource", typeof(ImageSource), typeof(ImageTextButton), new FrameworkPropertyMetadata(null));

        public ImageSource ImageSource
        {
            get { return GetValue(ImageSourceProperty) as ImageSource; }
            set { SetValue(ImageSourceProperty, value); }
        }
        #endregion


        #region readonly property
        private static readonly DependencyPropertyKey IsTextPropertyKey = DependencyProperty.RegisterReadOnly("IsText", typeof(bool), typeof(ImageTextButton), new FrameworkPropertyMetadata(false));

        public static readonly DependencyProperty IsTextProperty = IsTextPropertyKey.DependencyProperty;

        public bool IsText
        {
            get { return (bool)GetValue(IsTextProperty); }
            private set { SetValue(IsTextPropertyKey, value); }
        }
        #endregion


        #region clickEvent
        public static readonly RoutedEvent ClickEvent = EventManager.RegisterRoutedEvent("Click", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(ImageTextButton));

        public event RoutedEventHandler Click
        {
            add { AddHandler(ClickEvent, value); }
            remove { RemoveHandler(ClickEvent, value); }
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            RaiseEvent(new RoutedEventArgs(ClickEvent));
        }
        #endregion
    }
}
