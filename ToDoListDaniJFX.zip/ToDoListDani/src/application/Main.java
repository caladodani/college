package application;

import java.awt.Label;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;



public class Main extends Application {

	public static Task selectedTask = null;


	@SuppressWarnings({ "unchecked", "deprecation" })
	@Override

	public void start(Stage primaryStage) {
		try {
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root,800,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("To_Do_List");
			primaryStage.show();
			Date TodayDate=new Date();


			//RadioButtons
			RadioButton rb1=new RadioButton("All");
			RadioButton rb2=new RadioButton("Overdue");
			RadioButton rb3=new RadioButton("Today");
			RadioButton rb4=new RadioButton("This week");
			CheckBox chb= new CheckBox("Not Completed");
			chb.setId("chb");

			ToggleGroup Rgroup=new ToggleGroup();
			rb1.setToggleGroup(Rgroup);
			rb2.setToggleGroup(Rgroup);
			rb3.setToggleGroup(Rgroup);
			rb4.setToggleGroup(Rgroup);
			//spacing for the checkbox

			CheckBox chb2=new CheckBox("                                                                 ");

			chb2.setId("hide");

			HBox TopR_hbox =new HBox(10);
			TopR_hbox.setId("filterContaine2r");
			TopR_hbox.getChildren().addAll(chb2,chb);


			HBox Top_hbox =new HBox(10);
			Top_hbox.setId("filterContainer");
			Top_hbox.getChildren().addAll(rb1,rb2,rb3,rb4,TopR_hbox);

			rb1.setToggleGroup(Rgroup);



			//**********************************************
			//Menu Creation

			VBox vbt= new VBox(10);

			MenuBar menuBar = new MenuBar();

			Menu fileMenu= new Menu("File");

			menuBar.getMenus().add(fileMenu);

			vbt.getChildren().addAll(menuBar,Top_hbox);

			MenuItem newEntry = new MenuItem("New");

			fileMenu.getItems().add(newEntry);


	      	root.setTop(vbt);

	      	newEntry.setOnAction(new EventHandler<ActionEvent>(){
	      		@Override
				public void handle(ActionEvent arg0) {
	      			selectedTask = null;
	      			AddEditApointment aea = new AddEditApointment();
					aea.start();
				}

	      	});

	      	//**********************************************

			//Creation of the table
	      	TableView<Task> table = new TableView<Task>();
	      	TableColumn<Task,Boolean> Cl1 = new TableColumn<Task,Boolean>("Check box");
			TableColumn<Task,String> Cl2 = new TableColumn<Task,String>("Duedate");
			TableColumn<Task,String> Cl3 = new TableColumn<Task,String>("Title");
			TableColumn<Task,String> Cl4 = new TableColumn<Task,String>("%Completed");
			TableColumn<Task,String> Cl5 = new TableColumn<Task,String>("Description");

			//To store the data
			ObservableList<Task> Data = FXCollections.observableArrayList();
			ObservableList<Task> Data2 = FXCollections.observableArrayList();
			ObservableList<Task> Data3 = FXCollections.observableArrayList();
			ObservableList<Task> Data4 = FXCollections.observableArrayList();
			//To store the not Complete
			ObservableList<Task> Data0 = FXCollections.observableArrayList();
			ObservableList<Task> Data21 = FXCollections.observableArrayList();
			ObservableList<Task> Data31 = FXCollections.observableArrayList();
			ObservableList<Task> Data41 = FXCollections.observableArrayList();
			// to convert the data from string to date
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");


			FileReadWrite frw= new FileReadWrite();



			try {
				//if the file is imported the Name
				//if not imported path is needed
				   frw.ReadFile("ToDoList.txt",true, false);
				   String s;

				   while((s=frw.getLine()) != null) {
					   String[] col = s.split(";");

					   boolean col0=true;
					   int col3=Integer.parseInt(col[2]);


					   long ltime=TodayDate.getTime()+8*24*60*60*1000;
					   Date today8=new Date(ltime);


					   if(col3<100)
						    col0=false;

					   //----------------------------------------------------------------------------
					   if (formatter.parse(col[0]).getDate()<(TodayDate.getDate())){
						   if(col3<100)
							   Data21.add(new Task(col0,formatter.parse(col[0]),col[1],col3,col[3]));
						   //else
						   Data2.add(new Task(col0, formatter.parse(col[0]), col[1], col3, col[3]));


					   }

					   //-----------------------------------------------------------------------------------------

					   if (formatter.parse(col[0]).getDate()==(TodayDate.getDate())){
						   if(col3<100)
							   Data31.add(new Task(col0,formatter.parse(col[0]),col[1],col3,col[3]));
						//   else
						   Data3.add(new Task(col0, formatter.parse(col[0]), col[1], col3, col[3]));

					   }

					   //-----------------------------------------------------------------------------------------
					   if ((formatter.parse(col[0]).getDate()<=today8.getDate())&&(formatter.parse(col[0]).getDate()>=TodayDate.getDate())){
						   if(col3<100)
							   Data41.add(new Task(col0,formatter.parse(col[0]),col[1],col3,col[3]));

						   //else
						   Data4.add(new Task(col0, formatter.parse(col[0]), col[1], col3, col[3]));



					   }

					   //------------------------------------------------------------------------------------------------
					   if(col3<100)
						   Data0.add(new Task(col0,formatter.parse(col[0]),col[1],col3,col[3]));
					   //else
					   Data.add(new Task(col0,formatter.parse( col[0]), col[1], col3,col[3]));


				   }
			   }catch(IOException ioe) {
				   ioe.printStackTrace();
			   }finally {
				   frw.close();
			   }





			//Setting the values to the columns
			Cl1.setCellValueFactory(
					new PropertyValueFactory<Task, Boolean>("Checked"));
			Cl2.setCellValueFactory(
					new PropertyValueFactory<Task, String>("DueDate"));
			Cl3.setCellValueFactory(
					new PropertyValueFactory<Task, String>("Title"));
			Cl4.setCellValueFactory(
					new PropertyValueFactory<Task, String>("Complete"));
			Cl5.setCellValueFactory(
					new PropertyValueFactory<Task, String>("Description"));


			//Adding the Data to the table

			{
				Rgroup.selectedToggleProperty().addListener(
						(ov,oldToggle,newToggle)->{
							System.out.println("Radio buttons changed state.");




						if(rb1.isSelected())
						{



						    if(chb.isSelected())

						    	table.setItems(Data0);
						    else
						    	table.setItems(Data);


							System.out.println("radio button 1 is selected");

						}
						if(rb2.isSelected())
						{

						    if(chb.isSelected())
						    	table.setItems(Data21);
						    else
						    	table.setItems(Data2);

							System.out.println("radio button 2 is selected");


						}

						if(rb3.isSelected())
						{

						    if(chb.isSelected())
						    	table.setItems(Data31);
						    else
						    	table.setItems(Data3);




							System.out.println("radio button 3 is selected");

						}
						if(rb4.isSelected())
						{


						    if(chb.isSelected())
						    	table.setItems(Data41);
						    else
						    	table.setItems(Data4);




							System.out.println("radio button 4 is selected");

						}
						}

						);

				table.getColumns().addAll(Cl1,Cl2,Cl3,Cl4,Cl5);

				table.setOnMouseClicked(value->{
					if(value.getClickCount() == 2){
						selectedTask = table.getSelectionModel().getSelectedItem();
						AddEditApointment aea = new AddEditApointment();
						aea.start();
					}
				});

				root.setCenter(table);

				chb.selectedProperty().addListener(new ChangeListener<Boolean>() {
				    public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {

						if(rb1.isSelected())
						{

						    if(chb.isSelected())

						    	table.setItems(Data0);
						    else
						    	table.setItems(Data);


						}
						if(rb2.isSelected())
						{

						    if(chb.isSelected())
						    	table.setItems(Data21);
						    else
						    	table.setItems(Data2);

						}
						if(rb3.isSelected())
						{

						    if(chb.isSelected())
						    	table.setItems(Data31);
						    else
						    	table.setItems(Data3);





						}
						if(rb4.isSelected())
						{

						    if(chb.isSelected())
						    	table.setItems(Data41);
						    else
						    	table.setItems(Data4);


						}

				    }
					});
			}

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
