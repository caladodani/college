package application;
import java.text.SimpleDateFormat;
import java.util.Date;

import javafx.scene.control.CheckBox;

//import com.sun.glass.ui.Pixels.Format;
public class Task {
	private CheckBox Checked=new CheckBox();
	@SuppressWarnings("unused")
	private boolean check;
	private Date DueDate=new Date();

	private String Title;

	private int Complete =0;
	private String Description;


	public Task(boolean ck,Date dd,String ttl,int perc,String dscr){

		this.check=ck;
		if (ck)
			this.Checked.setSelected(true);
		else
			this.Checked.setSelected(false);
		this.DueDate=dd;
		this.Title=ttl;
		this.Complete=perc;
		this.Description=dscr;

	}
	//This is the individual set for each variable
	/*public void setChecked(boolean chk){
		this.check=chk;
		if (chk)
			this.Checked.setSelected(true);
		else
			this.Checked.setSelected(false);
	}
	public void setDate(Date dd){
		 this.DueDate=dd;
	 }
	 public void setTitle(String ttl){
		 this.Title=ttl;
	 }
	 public void setComplete(int perc){
		 this.Complete=perc;

	 }
	 public void setDescription(String dscr){
		 this.Description=dscr;
	 }*/

	 public CheckBox getChecked(){
			 return this.Checked;

	 }
	 public Date getDueDateF(){
		 return this.DueDate;
	 }
	 public String getDueDate(){
		 SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		 return formatter.format(this.DueDate);
	 }
	 public String getTitle(){
		 return this.Title;
	 }
	 public double getCompleteV(){
		 return (double) this.Complete;
	 }

	 public String getComplete(){
		 return this.Complete+"%";
	 }
	 public String getDescription(){
		 return this.Description;
	 }




}
