package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FileReadWrite {

	private File file = null;
	private FileReader fr = null;
	private BufferedReader br = null;
	private FileWriter fw = null;
	private PrintWriter pw = null;
	private long ln = 0;
	@SuppressWarnings("unused")
	private boolean intFile=false;


	//Read or Writes the selected file
	public void ReadFile(String path, boolean read,boolean intFile) throws IOException {
		ln = 0;
		if(intFile) {
			file = new File(getClass().getResource(path).getFile());
		}else {
			file = new File(path);
		}
		if(read) {
			fr = new FileReader(file);
			br = new BufferedReader(fr);
		}else {
			fw = new FileWriter(file);
			pw = new PrintWriter(fw);
		}
	}

	//Reads the line of the opened file
	public String getLine() throws IOException {
		if(br != null) {
			ln++;
			return br.readLine();
		}else {
			System.err.println("File opened only for writing");
			return null;
		}
	}

	//Prints the line of a line opened to reading
	public void ReadLine(String val) {
		if(pw != null) {
			ln++;
			pw.println(val);
		}else {
			System.err.println("File opened only for reading");
		}
	}

	public void WriteLine(String Val) {
		   try (BufferedWriter bw = new BufferedWriter(new FileWriter("ToDoList.txt", true))) {
		        bw.write(Val);
		        bw.newLine();

		    } catch (IOException e) {
		        e.printStackTrace();

		    }
	}

	public void Write(String Val) {
		   try (BufferedWriter bw = new BufferedWriter(new FileWriter("ToDoList.txt", true))) {
		        bw.write(Val);

		    } catch (IOException e) {
		        e.printStackTrace();

		    }
	}
	//Returns the line Number that it is reading
	public long getLn() {
		return ln;
	}

	//Closes the file
	public void close() throws IOException {
		if(fr != null) {
			fr.close();
		}
		if(fw != null) {
			fw.close();
		}
		if(pw != null) {
			pw.close();
		}
	}
}
