package application;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.io.*;
import java.util.*;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AddEditApointment implements Initializable{


	@FXML TextField titleidtxt;
	@FXML TextArea descriptxt;
	@FXML Slider perc;
	@FXML DatePicker DDdatepick;

	FileReadWrite frw;
	private String total;
	private String DataS;
	private LocalDate date;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		frw= new FileReadWrite();
		date=DDdatepick.getValue();

		if(Main.selectedTask != null){
			titleidtxt.setText(Main.selectedTask.getTitle());
			LocalDate  ld =Main.selectedTask.getDueDateF().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			DDdatepick.setValue(ld);
			perc.setValue(Main.selectedTask.getCompleteV());
			descriptxt.setText(Main.selectedTask.getDescription());

		}

	}


	public void start(){
		FXMLLoader loader = new FXMLLoader(getClass().getResource("Add.fxml"));
		Scene s = null;
		try{
			s = new Scene(loader.load());
		}catch(IOException ioe){
			ioe.printStackTrace();
		}

		Stage stage = new Stage();
		stage.setScene(s);
		stage.setTitle("Add Edit Apointment");
		stage.show();

	}

	@FXML
	public void Add_Save(ActionEvent a){

		String p = ((int)perc.getValue())+"";
		String t = titleidtxt.getText();
		String ds= descriptxt.getText();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

		String d=formatter.format(Date.from(DDdatepick.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant()));


		total=d+";"+t+";"+p+";"+ds+";";
		try {
				FileReadWrite reader = new FileReadWrite();
				reader.ReadFile("ToDoList.txt",true, false);
				String db = "";
				String aux;
				while((aux = reader.getLine()) != null){
					db += aux+"\n";
				}

			   frw.ReadFile("ToDoList.txt",false, false);

			   frw.Write(db);
			   frw.WriteLine(total);


		   }catch(IOException ioe) {
			   ioe.printStackTrace();
		   }finally {
			   try {
				frw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   }
		((Stage)titleidtxt.getScene().getWindow()).close();
		
	}

	@FXML
	public void Cancel(ActionEvent a){

		((Stage)titleidtxt.getScene().getWindow()).close();


	}

}
