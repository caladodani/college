#ifndef IOFILE_H
#define IOFILE_H

#include <QObject>
#include <QWidget>
#include <string>
#include <sstream>
#include <vector>
#include <fstream>
#include <iostream>

using namespace std;

class iofile
{
public:
    iofile();
    static vector<string*> readFile(string path);
    static void writeFile(string path, string file);
    static string* split(string l, char regex);




};

#endif // IOFILE_H
