#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "iofile.h"
#include "add.h"
#include <QMenu>
#include <QTextEdit>
#include <QLayout>
#include <QMenu>
#include <QMenuBar>
#include <QAction>
#include <QLabel>
#include <QGroupBox>
#include <QPushButton>
#include <QRadioButton>
#include <QTableView>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QCheckBox>
#include <QFileDevice>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <add.h>
#include <QAction>
#include <QDate>
#include <QString>
#include <QColor>
#include <QRgb>


QTableWidget* MainWindow::createTable(){
    table= new QTableWidget;
    table->horizontalHeader()->setStretchLastSection(true);
    table->verticalHeader()->setVisible(false);
    table->setColumnCount(5);
    header<<"Done"<<"DueDate"<<"Title"<<"%Completed"<<"Description";
    table->setHorizontalHeaderLabels(header);


    return table;
}

void MainWindow::refreshTable(vector<string*> data){

    table->setRowCount(data.size());
    for(unsigned int i=0;i<data.size();i++){

       QCheckBox *CheckBox1= new QCheckBox;
       QTableWidgetItem *date_widget = new QTableWidgetItem(QString::fromStdString(data.at(i)[0]));
       QTableWidgetItem *tittle_widget = new QTableWidgetItem(QString::fromStdString(data.at(i)[1]));
       QTableWidgetItem *percent_widget= new QTableWidgetItem(QString::fromStdString(data.at(i)[2]));
       QTableWidgetItem *description_widget = new QTableWidgetItem(QString::fromStdString(data.at(i)[3]));

       CheckBox1->setEnabled(false);

       if ((stoi(data.at(i)[2]))==100)
           CheckBox1->setChecked(true);
       table->setCellWidget(i,0,CheckBox1);
       table->setItem(i,1,date_widget);
       table->setItem(i,2,tittle_widget);
       table->setItem(i,3,percent_widget);
       table->setItem(i,4,description_widget);

       CheckBox1->setStyleSheet(QStringLiteral("QCheckBox::indicator {subcontrol-position: center;}"));
       date_widget -> setTextAlignment(Qt::AlignCenter);
       date_widget->setTextColor(QColor(0,0,255));

       tittle_widget -> setTextAlignment(Qt::AlignCenter);
       percent_widget->setTextAlignment(Qt::AlignCenter);
       description_widget->setTextAlignment(Qt::AlignCenter);
    }
}
void MainWindow::OpenW(){
    Add a;
    a.setMainWindow(this);
    a.setModal(true);
    a.exec();
}
void MainWindow::check(){

   vector<string*>  datach= iofile::readFile("D:\\Lab\\task.txt");

   for(int i=0;i<datach.size();i++){
       QString datS =QString::fromStdString(datach.at(i)[0]);
       QDate Date = QDate::fromString(datS,"dd/MM/yyyy");

       if(radio1->isChecked()){
           datach;
       }
       if(radio2->isChecked()){
           if (Date>QDate::currentDate())
               {
                   datach.erase(datach.begin()+i);
                   i--;
                   continue;
               }
       }
       if(radio3->isChecked()){
           if (Date!=QDate::currentDate())
                {
                   datach.erase(datach.begin()+i);
                   i--;
                   continue;
               }
       }
       if(radio4->isChecked()){
           if (Date<QDate::currentDate()||Date>QDate::currentDate().addDays(7))
               {
                   datach.erase(datach.begin()+i);
                   i--;
                   continue;
               }

       }
       if(ch1->isChecked())
       {
           if(std::stoi(datach.at(i)[2])==100){
               datach.erase(datach.begin()+i);
               i--;
           }
       }

   }
    refreshTable(datach);


   }
void MainWindow::tableItemClicked(int row, int column)
{

    QTableWidgetItem *item = new QTableWidgetItem;
    item = table->item(row,2);
    sline=item->data(Qt::DisplayRole).toString().toUtf8().constData();

    Add a;
    a.setMainWindow(this);
    a.start();
    a.setModal(true);
    a.exec();

}
string MainWindow::getString(){
    string a= sline;
    return a;
}



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),ui(new Ui::MainWindow)
{

    setObjectName("MainWindow");
    setWindowTitle("ToDoList");
    void createHorizontalGroupBox();
    QGroupBox *center= new QGroupBox(this);
    center->setMinimumSize(670,300);
    setCentralWidget(center);
    QMenuBar * menuBar = new QMenuBar(this);
      setMenuBar(menuBar);
    QMenu * menu = menuBar->addMenu("&File");
    QAction * action = new QAction("&New", this);
      connect(action, &QAction::triggered, this, &MainWindow::OpenW);
      menu->addAction(action);
    QVBoxLayout *Vlayout = new QVBoxLayout();
          QHBoxLayout *Hlayout = new QHBoxLayout();
          radio1 = new QRadioButton("All");
          radio2 = new QRadioButton("Overdoe");
          radio3 = new QRadioButton("Today");
          radio4 = new QRadioButton("This week");
          ch1 = new QCheckBox("Not Completed");
          Hlayout->addWidget(radio1);
          Hlayout->addWidget(radio2);
          Hlayout->addWidget(radio3);
          Hlayout->addWidget(radio4);
          Hlayout->addStretch(1);
          Hlayout->addWidget(ch1);
          Vlayout->addLayout(Hlayout);
          connect(radio1,SIGNAL(clicked()),this,SLOT(check()));
          connect(radio3,SIGNAL(clicked()),this,SLOT(check()));
          connect(radio4,SIGNAL(clicked()),this,SLOT(check()));
          connect(ch1,SIGNAL(clicked()),this,SLOT(check()));
          connect(radio2,SIGNAL(clicked()),this,SLOT(check()));
          Vlayout->addWidget(createTable());
          connect(table, SIGNAL(cellDoubleClicked(int,int)), this, SLOT(tableItemClicked(int,int)));
          centralWidget()->setLayout(Vlayout);
}




MainWindow::~MainWindow()
{

    delete ui;
}

