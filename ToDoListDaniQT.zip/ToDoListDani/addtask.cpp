#include "addtask.h"

AddTask::AddTask(QWidget *parent) :
    QMainWindow(parent),ui(new Ui::AddTask)
{

        ui->setupUi(this);

}
