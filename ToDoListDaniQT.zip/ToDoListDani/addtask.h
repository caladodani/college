#ifndef ADDTASK_H
#define ADDTASK_H

#include <QMainWindow>
#include <QWidget>

class AddTask
{
public:
    AddTask();
};

#endif // ADDTASK_H