#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QTableWidget>
#include <string>
#include <vector>
#include <iostream>
#include <QHBoxLayout>
#include <qradiobutton.h>
#include <QCheckBox>
#include <QtGlobal>

using namespace std;
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public slots:
    void check();
    void OpenW();
    void tableItemClicked(int row,int column);





public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void refreshTable(vector<string*> data);

    string getString();
    string sline;

//





private:
    QStringList header;
    QTableWidget *table;
    QTableWidget *createTable();
    QRadioButton *radio1 = new QRadioButton("All");
    QRadioButton *radio2;
    QRadioButton *radio3 = new QRadioButton("Today");
    QRadioButton *radio4 = new QRadioButton("This week");
    QCheckBox *ch1 = new QCheckBox("Not Completed");

    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
