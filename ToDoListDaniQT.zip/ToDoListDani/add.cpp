#include "add.h"
#include "ui_add.h"
#include "iofile.h"
#include "mainwindow.h"
#include <QString>

Add::Add(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Add)
{
    ui->setupUi(this);
}

void Add::start(){
    vector<string*> vari = iofile::readFile("D:\\Lab\\task.txt");
    for(unsigned int j=0;j<vari.size();j++)
    {
        if((vari.at(j)[1]==parent->getString())){
            ui->txtE->setText(QString::fromStdString(vari.at(j)[1]));
            ui->hs->setValue(std::stoi(vari.at(j)[2]));
            ui->det->setDate(QDate::fromString(QString::fromStdString(vari.at(j)[0]),"dd/MM/yyyy"));
            ui->txtE2->setText(QString::fromStdString(vari.at(j)[3]));
            ui->pushButton1->setText("Save");

        }

    }
}

Add::~Add()
{
    delete ui;
}

void Add::on_pushButton1_clicked()
{
    vector<string*> var = iofile::readFile("D:\\Lab\\task.txt");
    string line[4];
    line[0] = ui->det->text().toUtf8().constData();
    line[1] = ui->txtE->toPlainText().toUtf8().constData();
    int temp=ui->hs->value();
    line[2] = to_string(temp);
    line[3] = ui->txtE2->toPlainText().toUtf8().constData();

    for(unsigned int j=0;j<var.size();j++)
    {
        if((line[1]==var.at(j)[1])||(var.at(j)[1]==parent->getString())){
            var.erase(var.begin()+j);

        }

    }
    var.push_back(line);

    string foutput = "";
    unsigned int i;
    for(i=0; i<var.size(); i++){
        foutput += var.at(i)[0] + "," + var.at(i)[1] + "," + var.at(i)[2] + "," + var.at(i)[3] + "\n";
    }

    iofile::writeFile("D:\\Lab\\task.txt",foutput);

    parent->check();
    this->close();
}

void Add::on_pushButton_2_clicked()
{

    this->close();

}
