SIZE=5

def enqueue(queue): #entra
    if len(queue)==SIZE:
        print("Queue is full")
    else:
        n=input(str("new_entry:"))
        queue=[n]+queue
    return queue

def dequeue(queue):#sai
    if len(queue)==0:
        print("Queue is empty")
    else:
        elem=queue[len(queue)-1]
        del(queue[len(queue)-1])
        print(elem)
    return queue

def list(queue):
    print (queue,"server")


def menu():
    print(" ")
    print("1-Enqueue")
    print("2-Dequeue")
    print("3-List")
    print("4-Show Size")
    print("0-Quit")
    opcao=int(input("opcao:"))
    return opcao

def repetir(queue):
    opcao=menu()
    while opcao!=0:
        if   opcao==1:queue=enqueue(queue)
        elif opcao==2:queue=dequeue(queue)
        elif opcao==3:list(queue)
        elif opcao==4:print(len(queue))
        else :print("Opcao invalida")
        opcao=menu()
    print("Fim do programa")

fila=[]   # iniciar
repetir(fila)
