num=1
while num > 0:
   num =int( input('Escreva o número de segundos\n(ou um número negativo para terminar)\n?'))
   if num < 0:
       print ('Conversor a terminar')
       break
   dias =num/86400
   print('Aqui etá o número de dias:',dias)

