def conta_menores(t,n):
    conta = 0
    for i in range ( len(t)):
        if t[i] < n :
            conta = conta+1
    return conta
    
