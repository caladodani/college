def cinco(a):
 return a==5
    
   

    
        
