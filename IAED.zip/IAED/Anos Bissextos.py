def bissexto(x):
    if x % 4 == 0:
        if x % 100 != 0:
             print('é um ano bissexto')
        elif x % 400 == 0 :
            print('é um ano bissexto')
        else:
            print(' não é um ano bisssexto')
    else :
        print(' não é ano bissexto')
