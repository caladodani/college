def inserir_ord_rep(lst, elem):
        lst=lst+[0]
        i=len(lst)-1
        while lst[i-1]>elem and i>0:
                lst[i]=lst[i-1]
                i=i-1
        lst[i]=elem
        return lst
def inserir_seq_rep(lst,elem):
    return lst + [elem]

def inserir_seq_norep(lst,elem):
    if elem in lst :
        return 'já ta na lista'
    else:
        return lst+[elem]
def inserir_ord_norep(lst,elem):
    if elem in lst:return 'já ta na lista' 
    else:
        lst=lst+[0]
        i=len(lst)-1
        while lst[i-1]>elem and i>0:
                lst[i]=lst[i-1]
                i=i-1
        lst[i]=elem
        return lst
    
