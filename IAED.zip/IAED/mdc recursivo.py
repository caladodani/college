def mdc(m, n):
	if n == 0:
		return m
	else:
		return mdc(n, m % n)
x = int(input('introduza o dividendo:\n'))
y = int(input('introduza o divisor: \n'))
print(mdc(x,y))

