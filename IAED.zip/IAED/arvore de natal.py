def Arvore(n):
    print('- ' * (n-1) + '#' + '- ' * (n-2))
    z = n - 1
    x = 2
    for i in range(1,n):
        print('- '  *(z-i) + '*'* (x*i) + '- ' * (z-i))
    x+=2
    z-=1
Arvore(10)
def tronco(n,b):
    for i in range(n):
        print('- ' * (b-1)+ '#'  *2 + '- ' * (b-1))
tronco(3,9)
def base(n):
    for i in range(n):
        print('- '*3 + '#' *12 + '- ' * 3)
base(1)
