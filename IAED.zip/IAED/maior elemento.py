def maior_elemento(t):
    return max(t)
