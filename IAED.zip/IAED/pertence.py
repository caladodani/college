def pertence(elem,lst):
    i = 0  
    while i < len(lst):
        if lst[i] == elem:
            return True
        i = i+ 1
    return False
