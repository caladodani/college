MAX_HASH = 5
def hash_str(elem):
    n = len(elem)
    return (ord(elem[0])+ord(elem[n-1])+16*n)%MAX_HASH
def clearTable(n):
    table =[[] for i in range(n)]
    return table
def insert(elem, table):
    ii=hash_str(elem)
    if 0 in table[ii]:
        table[ii][0]=elem
    else:
        table[ii]=table[ii]+[elem]
def loadTable():
    table=clearTable(MAX_HASH)
    insert('GILLES',table)
    insert('Fernado',table)
    insert('Stirling Moss',table)
    insert('niki',table)
    insert('Jakie',table)
    return table
def findTable (elem, table):
    ii=hash_str(elem)
    return elem in table[ii]

tab=loadTable()
print (tab)



def menu():
    print(" ")
    print("1-Inserir")
    print("2-Procurar")
    print("3-Listar   ")
    print("0-Quit   ")
    opcao=int(input("opcao:"))
    return opcao

def repetir(hash_table):
    hash_table= loadTable()
    hash_table=clearTable(MAX_HASH)
    opcao=menu()
    while opcao!=0:
        if   opcao==1:
            n = input('O que pretende inserir?:')
            insert(n,hash_table)
        elif opcao==2:
            p= str(input('O que pertende procurar?:'))

            a=findTable(p,hash_table)
            return a
        elif opcao==3:print(hash_table)      
        else :print("Opcao invalida")
        opcao=menu()
    print("Fim do programa")
repetir(tab)
