def verificar_prefixo(prefixo, palavra):
    comp=len(prefixo)
    if comp > len(palavra): return False
    return prefixo in palavra[:comp]

def RomanaParaArabe(n_romano):
    lista = [(900, 'CM'),(90, 'XC'),(9,   'IX'),(400, 'CD'),(40, 'XL'),(4,   'IV'),(1000, 'M'),(500, 'D'),(100, 'C'),(50,  'L'),(10,  'X'),(5,   'V'),(1,   'I')]
    n=0
    while len(n_romano)>0:
        i=0
        while i <(len(lista)):
            if verificar_prefixo(lista[i][1], n_romano): 
                n_romano = n_romano[len(lista[i][1]):]
                n = n + lista[i][0]
                break
            i=i+1    
    return n

def ArabeParaHexa(n_Arabe):
    if (n < 0):
        print(0)
    elif (n<=1):
        print n,
    else:
        ArabeParaHexa( n / 16 )
        x =(n%16)
        if (x < 10):
            print(x), 
        if (x == 10):
            print("A"),
        if (x == 11):
            print("B"),
        if (x == 12):
            print("C"),
        if (x == 13):
            print("D"),
        if (x == 14):
            print("E"),
        if (x == 15):
            print ("F"),
