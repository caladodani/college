def triangular(n):
  a,b,c,d = 0,1,2,(1 or 3)
  while d<n:
      a=a+1
      b=b+1
      c=c+1
      d=a*b*c
  if d==n:
      print("é triangular")
  else:
       print("nao é triangular")
