def funçao(primo):
    for i in range(2,primo):
        if i != primo:
               i = primo % i
               if i == 0:
                   print ('nao é Primo')
        else:
               print('primo')
               break
