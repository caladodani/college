def carregar_triangulo(x,y):
    m =[[] for i in range(x)]
    for i in range (x):
        for j in range (y):
            m[i] = m[i]+['-']    
            if  i >= j:
                m[i][j]='*'

    return m 
matriz=carregar_triangulo(10,10)
##print(matriz)

def desnhar_trianguloD(matriz):
    for i in range (len(matriz)):
        n=''
        
        for j in range(len(matriz[i])):
            n=n  + matriz[i][j]
            
        print(n)


def print_arvore(matriz):
    for i in range (len(matriz)):
        n=''
        m=''
        for j in range(len(matriz[i])):
            n = n+matriz[i][j]
            m = matriz[i][j]+m
            
        print(m+n)
def estrela(y):
    print('-'*y+'#'+'-'*(y-1))

def tronco(y):
    for i in range(y//2):
        print('-'*((y//2)+2)+'#'*5+'-'*((y//2)+3))
        
def base(y):
    print('-'*(y//2)+'#'*9+'-'*((y//2)+1))

estrela(10)
print_arvore(matriz)
tronco(10)
base (10)

