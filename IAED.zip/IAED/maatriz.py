def matriz_verifica(x,y):
    linhas_x = len(x)
    linhas_y=len(y)
    colunas_x= len(x[0])
    colunas_y= len(y[0])
    if not linhas_x==linhas_y:
        return False
    for i in range(linhas_x):
        if not colunas_x==len(x[i])==len(y[i]):
            return False
        
        


def matriz_soma (m1,m2):
    mm=m1
    linhas=len(m1)
    colunas=len(m1[0])
    if not matriz_verifica(m1,m2):
        return 0
    for i in range(linhas):
        for j in range (colunas):
            mm[i][j]=mm[i][j]+m2[i][j]
    return mm

m11=[[2,3,4],[4,5,7]]
m22=[[1,1,1],[1,1,1]]
n=matriz_verifica(m11,m22)
m=matriz_soma(m11,m22)

print (m)

