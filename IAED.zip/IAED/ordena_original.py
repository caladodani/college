def bubbleSort(lst):
	maior_indice = len(lst) - 1
	nenhuma_troca = False
	while not nenhuma_troca:
		nenhuma_troca = True
		for i in range(maior_indice):
			if lst[i] > lst[i+1]:
				lst[i], lst[i+1] = lst[i+1], lst[i]
				nenhuma_troca = False
		maior_indice = maior_indice - 1
	print(lst)	

def ordena_indices(lst):
    lst2=[]
    for i in range(len(lst)):
        lst2[i] = lst2
        print (lst2)
    

    
        
        
                   
