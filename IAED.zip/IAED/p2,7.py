def fat(n):
        if n == 0:
            return 1
        else:
            return n*fat(n-1)
x = int(input('x='))
b = int(input('n='))
while b >= 0:
                ((x**b)/fat(b)) + ((x**(b-1))/fat(b-1))
                b= b-1
