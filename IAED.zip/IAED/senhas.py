IDs = ['Daniel','Tomas']
Senhas= ['123','321']
def acesso(ID):
    
    
