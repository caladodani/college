def juntos(t):
    conta = 0
    for i in range (len (t)-1):
        if t[i] == t[i+1]:
            conta = conta + i
    return conta
