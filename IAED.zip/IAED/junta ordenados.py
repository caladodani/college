def  junta_ordenados(a,b):
    return tuple(sorted(a+b))


