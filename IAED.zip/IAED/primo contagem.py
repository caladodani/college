import math
def primo(n):
    eh_primo=True
    for i in range(2, int(math.sqrt(n))+1):
        #para todos os nº entre 2 e raiz quadrada de n +1, se o resto da divisão inteira for 0, dá falso,caso contrario dá true
        if (n%i) ==0:
            eh_primo=False
    return eh_primo
def primos_até(n):
    for i in range(1,n):
        if primo(i):
            print(i)
def n_primos(n):
    conta,i=0,2
    while conta < n:
        if primo(i):
            print (i)
            conta=conta+1
        i=i+1
    

