num1=int(input(' numero da sequencia\n(introduza -1 para terminar)\n: '))
if num1 == -1:
    print ('')
num2=int(input(': '))
if num2 == -1:
    print ('aqui esta o nº inteiro formado pelos digitos',num1)
num3=int(input(': '))
if num3 == -1:
    print ('aqui esta o nº inteiro formado pelos digitos',num1,num2)
num4=int(input(': '))
if num4 == -1:
    print ('aqui esta o nº inteiro formado pelos digitos',num1,num2,num3)
num5=int(input(': '))
if num5 == -1:
    print ('aqui esta o nº inteiro formado pelos digitos',num1,num2,num3,num4)
num6=int(input(': '))
if num6 == -1:
    print ('aqui esta o nº inteiro formado pelos digitos',num1,num2,num3,num4,num5,)

print ('aqui esta o nº inteiro formado pelos digitos',num1,num2,num3,num4,num5,num6)
