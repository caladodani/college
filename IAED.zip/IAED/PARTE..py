def parte(lst,e):
    lstm=[]
    lstM=[]
    for i in range(0, len(lst)-1):
        if lst[i] < e+1:
            lstm= lstm +[i]
        if lst[i] >= e+1:
            lstM = lstM+[i]
        i= i+1
    return lstm,lstM
            
    
