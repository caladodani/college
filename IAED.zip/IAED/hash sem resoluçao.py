MAX_HASH  =5
def hash(n):
    return n % MAX_HASH
def clearTable(n):
    table =[0 for i in range(n)]
    return table

def insert(elem, table):
    ii=hash(elem)
    if table[ii]==0:
        table[ii]=elem
    else:
        print("colisão")
def loadTable():
    table=clearTable(MAX_HASH)
    insert(245,table)
    insert(342,table)
    insert(194,table)
    insert(923,table)
    insert(556,table)
    
    return table
def findTable (elem, table):
    return table[hash(elem)]==elem

tab=loadTable()
print (tab)
print(findTable(194, tab))
print(findTable(200, tab))
