def main(a):
    n= RomanaParaArabe(a)
    return hexadecimal(n)
    

def verificar_prefixo(prefixo, palavra):
    comp=len(prefixo)
    if comp > len(palavra): return False
    return prefixo in palavra[:comp]
def RomanoParaArabe(n_romano):
    lista = [(900,'CM'),(90,'XC'),(9,'IX'),(400, 'CD'),(40, 'XL'),(4,'IV'),
(1000, 'M'),(500,'D'),(100,'C'),(50,'L'),(10,'X'),(5, 'V'),(1,'I')]
    n=0
    while len(n_romano)>0:
        i=0
        while i <(len(lista)):
            if verificar_prefixo(lista[i][1], n_romano): 
                n_romano = n_romano[len(lista[i][1]):]
                n = n + lista[i][0]
                break
            i=i+1    
    return n

def ArabeParaHexadecimal(n):
    a=''
    l_hexadecimal=['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F']
    for i in range(3):
        a= a+ l_hexadecimal[n%16]
        n=n//16
    b= a[2]+a[1]+a[0]
    for j in range (2):
        if b[0]=='0':
            b=b[1:]
    return b
                
roma = input('Indroduza o número romano, para converter em hexadecimal:')
print(ArabeParaHexadecimal(RomanoParaArabe(roma)))
      
            
            
            
        
    
