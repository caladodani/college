def escrever_prefixo(n,p):
        return str(p[:n])
        

def escrever_sofixo(n,p):
        return str(p[-n:])




def organiza_lista(lst):
        c = 0
        while c<len(lst)-1:
                for i in range(0,len(lst)-1):
                        if lst[i] > lst[i+1]:
                                  lst[i], lst[i+1] = lst[i+1], lst[i]
                c = c+1                  
        print(lst)
lista = ['telégrafo', 'ditongo', 'dilema', 'diálogo', 'diagonal','diafragma', 'diagrama','dispneia','disenteria', 'dispepsia', 'hipodérmico', 'metamorfose', 'metáfora', 'metacarpo', 'paralelo', 'parasita', 'paradoxo', 'paradigma', 'periferia', 'peripécia', 'período', 'periscópio', 'prólogo', 'prognóstico', 'profeta', 'programa', 'antídoto', 'antipatia', 'antagonista', 'antítese', 'apoteose', 'apóstolo', 'apocalipse', 'hipótese', 'prosélito', 'prosódia', 'proto-história', 'protótipo', 'protomártir', 'polissílabo', 'polissíndeto', 'politeísmo', 'síntese', 'sinfonia', 'simpatia', 'sinopse', 'televisão', 'telepatia', 'disfasia', 'eclipse', 'êxodo', 'ectoderma', 'exorcismo', 'encéfalo', 'embrião', 'elipse', 'entusiasmo', 'endovenoso', 'catarata', 'dissílabo', 'endocarpo', 'endosmose', 'epiderme', 'epílogo', 'epidemia', 'epitáfio', 'eufemismo', 'euforia', 'eucaristia', 'eufonia','hemisfério', 'hemistíquio', 'hemiplégico', 'hipertensão', 'hipérbole', 'anónimo', 'amoral', 'ateu', 'afônico', 'analogia', 'análise', 'anagrama', 'anacrônico', 'anfiteatro', 'anfíbio', 'anfibologia', 'apologia', 'arquiduque', 'arquétipo', 'arcebispo', 'arquimilionário', 'cataplasma', 'catálogo',  'hipertrofia', 'hipocrisia']
