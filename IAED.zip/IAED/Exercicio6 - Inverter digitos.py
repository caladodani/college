print('Introduza um número inteio positivo:')
num = int(input('?'))
numinv = ''
while num > 0:
    digito = num % 10 # obter o algarismo das unidades
    numinv += str(digito) # construir o número invertido adicionando um digito
    num = num // 10 # remover o algarismo das unidades
print('O número invertido é:',numinv)
