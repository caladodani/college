def multi_rec(a,b):
    if b==1:return a
    else:
        return a + multi_rec(a,b-1)

def multi_it(a,b):
    c=a
    while b>1:
        a=a+c
        b=b-1
    return a

def potencia_rec(base,exp):
    if exp==1:return base
    else:
        return base*potencia_rec(base,exp-1)

def potencia_it(base,exp):
    c=base
    while exp!=1:
        base=base*c
        exp=exp - 1
    return base
