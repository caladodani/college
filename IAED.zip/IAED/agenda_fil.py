SIZE=20

def Adicionar(Lista): 
    if len(Lista)<=SIZE:
        a=[]
        n=str(input("Indroduza o nome:"))
        m=int(input("Indroduza o número:"))
        e=str(input("Indroduza o email:"))
        a= a +[n]+[m]+[e]
        existe=False
        if len(Lista)==0:
            Lista=[a]+Lista

            
        else:
            for i in range(len(Lista)):

                if Lista[i]==a:
                    print('já está na agenda')
                    existe=True
                
            if existe==False:
                Lista=[a]+Lista
        
    else:print("agenda cheia",Lista)
    return sorted(Lista)



def list(Lista):
    print (Lista,"server")

def findTable(elem,table):
    existe=False
    for i in range(len(table)): 
        if table[i][0]==elem:
            existe = True
            j=i

    if existe == True: return table[j]
    else:    
            print('Não esta na agenda')
def Remover(Lista):
    if len(Lista)==0:
        print("Agenda Vazia")
    else:
        n=str(input("Qual contacto pertende apagar?"))
        existe=False
        for i in range(len(Lista)): 
            if Lista[i][0]==n:
                existe = True
                j=i

        if existe == True:
            del(Lista[j])
            return Lista
        else:    
                print('Não esta na agenda')



def menu():
    print(" ")
    print("1-Procurar contacto (nome)")
    print("2-Inserir contacto")
    print("3-Apagar Contacto")
    print("4-Listar Contactos")
    print("0-Terminar  ")
    opcao=str(input("Option:"))
    return opcao

def repetir(Lista):
    opcao=menu()
    while opcao!='0':
        if   opcao=='1':
            n=input('O que deseja procurar?')
            print(findTable(n,Lista))
            
        if opcao=='2':
             Lista =Adicionar(Lista)
             print( Lista)
            
        elif opcao=='3':
            Lista=Remover(Lista)
            print(Lista)    
        
        elif opcao=='4':
            print('\n ')
            print(sorted(Lista))
        
        else:
            print('Opção invalida')
        opcao=menu()
    if opcao=='0':print("Fim do programa")
    

fila1=[]   

repetir(fila1)

