Ids=['Daniel','Calado']
senhas = ['111','222']
def login():
    username = input ('Username: ')
    if username in Ids:
        if username == Ids[0]: 
            count = 3
            while count > 0:
                password = input ('Password: ')
                if password == senhas[0]: 
                    print('Acesso permitido')
                    return
                else:count-=1
                if count == 0:
                    print('Acesso bloqueado, contacte o administrador de sistema.')
                    return
                else: print('Senha incorrecta')
        if username == Ids[1]: 
            count = 3
            while count > 0:
                password = input ('Password: ')
                if password == senhas[1]: 
                    print('Acesso permitido')
                    return
                else:count-=1
                if count == 0:
                    print('Acesso bloqueado, contacte o administrador de sistema.')
                    return
                else: print('Senha incorrecta')
    else:print('Utilizador invalido.')
