MAX_HASH = 5

def hash(n):
    return n%MAX_HASH

def clearTable(n):
    table =[0 for i in range(n)]
    return table

        
def insert(elem, table):
    ii=hash(elem)
    if table[ii]==0:
        table[ii]=elem
    else:
        print("Já ta na lista")
        
def loadTable():
    table=clearTable(MAX_HASH)
    insert(245,table)
    insert(342,table)
    insert(194,table)
    insert(923,table)
    insert(556,table)
    return table

def findTable(elem,table):
    return table[hash(elem)]==elem


def menu():
    print(" ")
    print("1-Inserir")
    print("2-Procurar")
    print("3-Listar   ")
    print("0-Quit   ")
    opcao=int(input("opcao:"))
    return opcao

def repetir(hash_table):
    hash_table= loadTable()
    hash_table=clearTable(MAX_HASH)
    opcao=menu()
    while opcao!=0:
        if opcao==1:
            n = input('O que pretende inserir?:')
            insert(n,hash_table)
        elif opcao==2:
            p = str(input('O que pertende procurar?:'))
            print(findTable(p,hash_table))
        elif opcao==3:print(hash_table)      
        else :print("Opcao invalida")
        opcao=menu()
    print("Fim do programa")

hash_table= loadTable()


