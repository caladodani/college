SIZE=5

def enqueue(queue): #entra
    if len(queue)==SIZE:
        print("Queue is full")
    else:
        n=str(input("nova entrada:"))
        queue=[n]+queue
    return queue

def dequeue(queue):#sai
    if len(queue)==0:
        print("Queue is empty")
    else:
        elem=queue[len(queue)-1]
        del(queue[len(queue)-1])
        print(elem)
    return queue

def list(queue):
    print (queue,"server")


def menu():
    print(" ")
    print("11-Enqueue")
    print("12-Enqueue")
    print("21-Dequeue")
    print("22-Dequeue")
    print("3-List")
    print("0-Quit")
    opcao=int(input("opcao:"))
    return opcao

def repetir(queue,queue1):
    opcao=menu()
    while opcao!=0:
        if   opcao==11:queue=enqueue(queue)
        if opcao==12:queue1=enqueue(queue1)
        elif opcao==21:queue=dequeue(queue)
        elif opcao==22:queue1=dequeue(queue1)
        elif opcao==3:list(queue), list(queue1) 
        elif opcao !=11 or opcao !=12 or opcao !=21 or opcao !=22 or opcao !=3:print("Opcao invalida")
        opcao=menu()
    print("Fim do programa")

fila1=[]   
fila2=[] 
repetir(fila1,fila2)

