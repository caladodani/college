def  junta_ordenados(a,b):
    return tuple(sorted(a+b))


#consegui fazer sem usar a função sorted, tive que usar index para o fazer:
def junto_ordenados(t,n):
    a = ()
    b = ()
    d =()
    while len(t)>0: 
        minimo = t[0]  
        for x in t: 
            if x < minimo:
                minimo = x
        a = a + (minimo,)
        minimo_index = t.index(minimo)
        t = t[:minimo_index] + t[minimo_index+1:]
    while len(n)>0:
        minimo2 = n[0]  
        for y in n: 
            if y < minimo2:
                minimo2 = y
        b = b + (minimo2,)
        minimo2_index = n.index(minimo2)
        n = n[:minimo2_index] + n[minimo2_index+1:]
    c = a + b
    while len(c)>0:
        minimo3 = c[0]  
        for z in c: 
            if z < minimo3:
                minimo3 = z
        d = d + (minimo3,)
        minimo3_index = c.index(minimo3)
        c = c[:minimo3_index] + c[minimo3_index+1:]
    return d
