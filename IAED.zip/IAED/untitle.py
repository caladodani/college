seg=int(input('segundos:'))
while seg>0:
 minut=seg/60
 horas=minut/60
 dias=horas/24
 print('dias:',dias)
 seg=int(input('segundos:'))


conf=int(input('tem a certeza?(1=sim,2=não)'))
if conf == 1:
     print('Encerrando Programa.')
if conf == 2 :
     seg=int(input('segundos:'))
     

 
