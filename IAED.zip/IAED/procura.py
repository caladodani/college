def procura_bin (lst, chave):
	linf = 0
	lsup = len(lst) - 1
	while linf <= lsup:
		meio = (linf + lsup) // 2
		if chave == lst[meio]:
			return meio
		elif chave > lst[meio]:
			linf = meio + 1
		else:
			lsup = meio - 1
	return -1







