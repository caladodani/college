def soma_elementos(t):
    soma = 0
    for i in range (len(t)):
        soma = soma + t[i]
    return soma

def  tuplo_ordenado(n):
    for i in range (len(n)-1):
        if n[i] > n[i+1]:
            return False
        return True

