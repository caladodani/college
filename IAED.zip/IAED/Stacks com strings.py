SIZE= 5

def push(stack):#carregar
    if len(stack)==SIZE:
        print("Stack Overflow")
    else:
        n=input("valor:") #alteração para strings
        stack=stack+[n]
    return stack 


def pop(stack): #descarregar
    if len(stack)==0:
        print("Stack Underflow")
    else:
        elem=stack[len(stack)-1]
        del(stack[len(stack)-1])
        print(elem)
    return stack

def list(stack): #mostra a pilha
    print (stack)
    
def pointer (stack): # mostra o tamnho da pilha
     return len(stack)

def menu():
    print(" ")
    print("1-Push")
    print("2-Pop")
    print("3-List")
    print("4-Point")
    print("0-Quit")
    opcao=int(input("opcao:"))
    return opcao
def repetir(stack):
    opcao=menu()
    while opcao!=0:
        if   opcao==1:stack=push(stack)
        elif opcao==2:stack=pop(stack)
        elif opcao==3:list(stack)
        elif opcao==4:print( pointer(stack))
        else :print("Opcao invalida")
        opcao=menu()
    print("Fim do programa")

pilha=[]  #inicializar pilha
repetir(pilha)
