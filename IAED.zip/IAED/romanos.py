
def romanos(a):
    unidades = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", ""]
    dezenas = ["X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC", ""]
    centenas = ["C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM", ""]
    milhares = ["M", "MM", "MMM", ""]
    N = str(a)
    i = int(N[-1])
    x = int(N[-2])
    c = int(N[-3])
    m = int(N[-4])
    M = milhares[m-1]
    C = centenas[c-1]
    X = dezenas[x-1]
    I = unidades[i-1]

    print( N, "=", M+C+X+I)
