def quadrado(nl):
    c=' ☻ '
    for i in range(nl):
        if i == 0 or i==(nl-1):
            print(c* nl)
        else:
                print(c,''*(nl-8),c)

def quadrado2(ml,mc):
    c='☻'
    m=ml*[mc*[c]]
    for i in range(ml):
        for j in range(mc):
            print(m[i][j],end="")
        print(" ")

