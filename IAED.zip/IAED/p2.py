num =int(input('Escreva um inteiro positivo\n?'))
soma =0
while num >0:
    digito=num %10# obtém as unidades
    num = num//10 #remove o algarismo das unidades
    soma = soma+digito
print('soma dos digitos:',soma)
print('Duvidas das minhas contas????')
