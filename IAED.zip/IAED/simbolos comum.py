def simbolos_comum(s1, s2):
    s_comum = ''
    for s in s1:
        if s in s2:
            s_comum = s_comum + s
    return s_comum
