#fibonacci recursivo
def fibonacci_rec(n):
    if n == 0: return 1
    elif n == 1: return 1
    else: return fibonacci_rec(n-1) + fibonacci_rec(n-2)

#fibonacci iterativo
def fibonacci_it(m):
    a,b = 1,1
    if m ==0 or m==1:return 1
    else:
        for i in range(2,m):
            a,b=b,a+b
            #print(a,b)
        return a+b
 
