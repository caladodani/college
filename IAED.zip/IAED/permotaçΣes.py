
def swap(palavra, ii, jj):
    palavra[ii],palavra[jj]=palavra[jj],palavra[ii]

def permute(palavra, i): #a função do i é escolher as posições que se pertendem fixar
    if i==len(palavra):
            print(palavra[0]+palavra[1]+palavra[2]+palavra[3])
    else:
       for j in range (i, len(palavra)): 
            swap (palavra, i, j)
            permute (palavra, i+1)
            swap (palavra, i, j)
           

pal=['R','O','M','A']
permute(pal,0)
