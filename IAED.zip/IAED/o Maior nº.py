num1=int(input('Coloque o 1º Valor\n'))
num2=int(input('Coloque o 2º Valor\n'))
num3=int(input('Coloque o 3º Valor\n'))
if num1 > num2 and num1 > num3:
    print('O maior nº é:',num1)
if num2 > num1 and num2 > num3:
    print('O maior nº é:',num2)
if num3 > num1 and num3 > num2:
    print('O maior nº é:',num3)
num1=int(input('Coloque o 1º Valor\n'))
num2=int(input('Coloque o 2º Valor\n'))
num3=int(input('Coloque o 3º Valor\n'))
