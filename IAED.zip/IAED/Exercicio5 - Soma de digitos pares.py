print('Insira um numero inteiro positivo')
num = int(input('?'))
somadp = 0 # variável que permite somar os digitos pares
while num > 0:
    digito = num % 10 # obter o algarismo das unidades
    if digito % 2 == 0: # verificar se o digito é par
        somadp += digito
    num = num // 10 # remover o algarismo das unidades
print('Soma dos digitos pares:',somadp)
