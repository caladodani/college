for f in range(-40,121):
    c=5/9 *(f-32)
    print('Farenhiet:',f,'Fº','---- Celsius:',c ,'Cº')


