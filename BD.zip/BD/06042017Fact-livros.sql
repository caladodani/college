use FactLivros
--Exercicio 1
--Listar toda a informa��o dos livros existentes, ordenada por t�tulo.

select * from Livro order by Titulo

--Execicio 2
--Listar as editoras existentes.

select distinct Editora From Livro

--Exercicio 3
--Listar os t�tulos da editora �Addison-Wesley�.

select * from Livro where Editora ='Addison-Wesley'

--Exercicio 4
--Listar o t�tulo, editora, edi��o e o c�digo dos autores de todos os livros, ordenada por t�tulo.

select Titulo, Edicao, Editora, Autor
from Livro INNER JOIN Autoria
	on Livro.Livro = Autoria.Livro
order by Titulo

--Exercicio 5
--Listar o t�tulo, editora, edi��o e o nome dos autores de todos os livros, ordenada por t�tulo.

select Titulo, Edicao, Editora, Nome
from (Livro INNER JOIN Autoria
	on Livro.Livro = Autoria.Livro)
	inner join Autor
	on Autoria.Autor = Autor.Autor
order by Titulo

--Exercicio 6
--Listar todos os livros de �DATE, Chistopher J.�

select Titulo, Edicao, Editora, Nome
from (Livro INNER JOIN Autoria
	on Livro.Livro = Autoria.Livro)
	inner join Autor
	on Autoria.Autor = Autor.Autor
where Nome = 'DATE, Christopher J.'
order by Titulo

--Exercicio 7
--Listar o nome de todos os autores com livros editados, indicando o n�mero de livros de sua autoria, ordenado por nome.

select Nome, COUNT(*)
from Autor INNER JOIN Autoria
	on Autor.Autor = Autoria.Autor
group by Nome

select Nome, COUNT(*) as NLivros
from Autor as a inner join Autoria as Au
	on A.Autor = Au.Autor
group by Nome

--Exercicio 8
--Listar o nome de todos os autores, indicando o n�mero de livros de sua autoria, ordenado por nome.

select Nome, COUNT(*) as NLivros
from Autor as a LEFT join Autoria as Au
	on A.Autor = Au.Autor
group by Nome

select *
from Autor as a left join Autoria as Au
	on a.Autor = Au.Autor

--exercicio 9
--Listar o nome e nacionalidade dos autores de nacionalidades Portuguesa e Inglesa.

select Nome, Nacionalidade 
from Autor
--where Nacionalidade = 'Inglesa' or Nacionalidade = 'Portuguesa'
where Nacionalidade in ('Portuguesa','Inglesa')

--Exercicio 10
--Listar os t�tulos e n�mero de edi��es dos livros com n�mero de edi��es entre 4 e 10.

select Titulo, Edicao
from Livro
where Edicao between 4 and 10

--Exercicio 11
--Listar os valores das facturas, considerando o IVA a 23%. Indicar atrav�s de uma string que o valor engloba o IVA. (Ver nota no final)

select Factura, sum (Quantidade +Preco)*1.23 ,'IVA ICLUIDO'
from item I inner join Livro L
	on I.Livro = L.Livro
group by Factura 

--Exercicio 12
--Indicar o n�mero de livros existentes.

select COUNT(*)
from Livro

--Exercicio 13
--Indicar o n�mero de livros existentes com edi��o conhecida.

select COUNT(*)
from Livro
where Edicao is not null

--Exercicio 14
--Indicar o n�mero de livros existentes com edi��o desconhecida.

select COUNT(*)
from Livro
where Edicao is null

--Exercicio 15
--Listar, para cada editora, o n�mero m�ximo de edi��es existentes do livro com maior n�mero de edi��es dessa editora.	

select  Editora, MAX (Edicao)
from Livro
group by Editora

--Exercicio 16
--Listar o t�tulo de todos os livros, indicando o n�mero de autores que escreveram o livro.

select Titulo, COUNT(Autor)
from Livro L LEFT JOIN Autoria Au
	on L.Livro = Au.Livro
group by Titulo

--Exercicio 17 
--Listar para cada editora o n�mero m�ximo de edi��es existentes num livro dessa editora. Apenas considerar as editoras cujo valor m�ximo de edi��es seja superior a 4.

Select Editora, MAX(Edicao)
from Livro
group by Editora
	having Max(Edicao) > 4 

--Exercicio 18
--Listar o nome e m�dia dos valores das facturas por cliente. (Ver nota no final)

select Cliente, avg(T.Total) Media
	from Factura F inner join
	(select Factura, sum(Quantidade * Preco) Total
	from Item I inner join  Livro L 
		on I.Livro = L.Livro
	group by Factura) T
		on F.Factura = T.Factura
group by Cliente

--Exercicio 19
--Listar para cada nome de autor, o total de livros por ele editado.

select Nome, COUNT (Livro )
From Autor A left join Autoria Au
	on A.Autor = Au.Autor
group by Nome

--Exercicio 20
--Listar o nome de todos os autores com livros editados, indicando o n�mero de livros de sua autoria, ordenado por nome. (Utilizar uma UNION)

select Nome, COUNT(*) NLivros
from Autor A, Autoria Au
where A.Autor = Au.Autor
group by Nome
union all
select Nome, 0 NLivros
from Autor
where Autor not in (select Autor from Autoria)

-- Exercicio 21
--Listar ordenadamente os nomes dos autores que n�o t�m livros escritos.

select Nome 
from Autor a left join Autoria Au
	on a.Autor = Au.Autor
group by Nome
	having COUNT(Livro) = 0
order by Nome

-- Exercicio 22
--Listar os nomes dos cinco autores com mais livros, indicando o n�mero de livros.

select top 5 with ties Nome, COUNT (Livro ) NLivros
From Autor A left join Autoria Au
	on A.Autor = Au.Autor
group by Nome
order by NLivros desc, Nome

--Exercicio 23
--Seleccionar o titulo e o n�mero de edi��es do livro com maior n�mero de edi��es.

select top 1 Titulo, Edicao
from Livro 
order by Edicao desc

--Exercicio 24
--Listar, para cada editora, o(s) livro(s) com maior n�mero de edi��es, ordenado por editora.

select L.Editora, Titulo, Edicao
from Livro L
inner join
(select Editora, Max (Edicao) MaxEdicao
from Livro
group by Editora) L1
	on L.Editora = L1.Editora and L.Edicao = L1.MaxEdicao

--Exercicio 25
--Listar, para cada editora, o n�mero de livros com maior n�mero de edi��es, ordenado por editora.

select L.Editora,COUNT(Livro) NLivros
from Livro L
inner join
(select Editora, Max (Edicao) MaxEdicao
from Livro
group by Editora) L1
	on L.Editora = L1.Editora and L.Edicao = L1.MaxEdicao
group by L.Editora

--Exercicio 26
--Seleccionar os nomes dos autores que editam numa editora em que mais nenhum outro autor edita.

select Nome 
FROM Autor  A INNER JOIN Autoria Au	
	ON A.Autor = Au.Autor
	INNER JOIN Livro L
	ON Au.Livro = L.Livro
WHERE Editora in
	(select Editora
	from Livro L inner join Autoria Au
		on L.Livro = Au.Livro
	GROUP BY Editora
		HAVING COUNT (Autor) = 1)

--exercicio 27
--Listar os nomes dos autores que editaram livros em mais que uma editora.

Select Nome 
From Autor A INNER JOIN Autoria Au 
	On A.Autor = Au.Autor
	INNER JOIN Livro L On Au.Livro = L.Livro
Group by Nome 
	HAVING COUNT(DISTINCT Editora) > 1

--Exercicio 28
--Listar o nome dos autores que t�m livros em parceria.

select Nome, Livro
from Autor A INNER JOIN Autoria Au
	ON A.Autor = Au.Autor
WHERE Livro IN
	(SELECT L.Livro
	FROM Livro L INNER  JOIN Autoria Au
		ON L.Livro = Au.Livro
	GROUP BY L.Livro
		HAVING COUNT(AUTOR)>1)

--Exercicio 29
--Listar pares de nomes de autores que editaram o mesmo n�mero de
livros.

select A1.Nome, A2.Nome
from
	(select Nome , COUNT(Livro ) NLivros 
	from Autor A inner join Autoria Au 
		on A.Autor = Au.Autor
	group by Nome ) A1
inner join
	(select Nome, COUNT(Livro) NLivros 
	from Autor A inner join Autoria Au 
		on A.Autor = Au.Autor
	group by Nome )A2
on A1.NLivros = A2.NLivros
Where A1.Nome > A2.Nome

--Exerciicio 30
--Calcular o valor dos itens das facturas (Quantidade * Preco).
update item
	set valor = Quantidade = Preco
from item i inner join Livro L 
	on i.Livro = L.Livro
where valor is null

--Exercicio 31
--Calcular o valor total das facturas.
update Factura
	set Total = TFact
from Factura F inner join 
	(select Factura, sum(valor) TFact
		from Item
	group by Factura) T
		on f.Factura = t.Factura
where Total is null

--Exercicio 32
--Anular os recibos com data de pagamento a NULL
delete from Recibo
	where Data_pagamento is null

--Exercicio 33
--Gerar os recibos das facturas cujo montante seja superior a 75 euros.
insert Factura(Cliente)
	Values (3)

insert Item (Factura, Item, Livro, Quantidade)
	values (15,1 ,12,1)
	
insert Item (Factura, Item, Livro, Quantidade)
	values (15,2 ,4,2)
	
insert Item (Factura, Item, Livro, Quantidade)
	values (15,3 ,6,1)

--Exercicio 34
--Gerar os recibos das facturas cujo montante seja superior a 75 euros.
insert Recibo (Factura )
	select Factura
		from Factura
		where Total>75
			and Factura not in (select Factura from Recibo)
