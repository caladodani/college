USE FactLivros

-- Exercicio 1
SELECT * FROM Livro ORDER BY Titulo

-- Exercicio 2
SELECT DISTINCT Editora FROM Livro

-- Exercicio 3
SELECT * FROM Livro WHERE Editora = 'Addison-Wesley'

-- Exercicio 4
SELECT Titulo, Edicao, Editora, Autor
FROM Livro INNER JOIN Autoria
	ON Livro.Livro = Autoria.Livro
ORDER BY Titulo

-- Exercicio 5
SELECT Titulo, Edicao, Editora, Nome
FROM (Livro INNER JOIN Autoria
	ON Livro.Livro = Autoria.Livro)
	INNER JOIN Autor
	ON Autoria.Autor = Autor.Autor
ORDER BY Titulo

-- Exercicio 6
SELECT Titulo, Edicao, Editora, Nome
FROM (Livro INNER JOIN Autoria
	ON Livro.Livro = Autoria.Livro)
	INNER JOIN Autor
	ON Autoria.Autor = Autor.Autor
WHERE Nome = 'DATE, Christopher J.'
ORDER BY Titulo

-- Exercicio 7
SELECT Nome, COUNT(*) AS Nlivros
FROM Autor INNER JOIN Autoria
	ON Autor.Autor = Autoria.Autor
GROUP BY Nome

SELECT Nome, COUNT(*) AS NLivros
FROM Autor AS A INNER JOIN Autoria AS Au
	ON A.Autor = Au.Autor
GROUP BY Nome

-- Exercicio 8
SELECT Nome, COUNT(Livro) AS NLivros
FROM Autor AS A LEFT JOIN Autoria AS Au
	ON A.Autor = Au.Autor
GROUP BY Nome

SELECT *
FROM Autor AS A LEFT JOIN Autoria AS Au
	ON A.Autor = Au.Autor

-- Exercicio 9
SELECT Nome, Nacionalidade
FROM Autor
--WHERE Nacionalidade = 'Inglesa' OR Nacionalidade = 'Portuguesa'
WHERE Nacionalidade IN ('Portuguesa','Inglesa')

-- Exercicio 10
SELECT Titulo, Edicao
FROM Livro
WHERE Edicao BETWEEN 4 AND 10

-- Exercicio 11
SELECT Factura, SUM(Quantidade * Preco) * 1.23, 'IVA Incluido'
FROM Item I INNER JOIN Livro L
	ON I.Livro = L.Livro
GROUP BY Factura

-- Exercicio 12
SELECT COUNT(*)
FROM Livro

-- Exercicio 13
SELECT COUNT(*)
FROM Livro
WHERE Edicao IS NOT NULL

-- Exercicio 14
SELECT COUNT(*)
FROM Livro
WHERE Edicao IS NULL

-- Exercicio 15
SELECT Editora, MAX(Edicao)
FROM Livro
GROUP BY Editora

-- Exercicio 16
SELECT Titulo, COUNT(Autor)
FROM Livro L LEFT JOIN Autoria Au
	ON L.Livro = Au.Livro
GROUP BY Titulo

-- Exercicio 17
SELECT Editora, MAX(Edicao)
FROM Livro
GROUP BY Editora
	HAVING MAX(Edicao) > 4

-- Exercicio 18
SELECT Cliente, AVG(T.Total) Media
FROM Factura F INNER JOIN
	(SELECT Factura, SUM(Quantidade * Preco) Total
	FROM Item I INNER JOIN Livro L
		ON I.Livro = L.Livro
	GROUP BY Factura) T
		ON F.Factura = T.Factura
GROUP BY Cliente

-- Exercicio 19
SELECT Nome, COUNT(Livro)
FROM Autor A LEFT JOIN Autoria Au
	ON A.Autor = Au.Autor
GROUP BY Nome

-- Exercicio 20
SELECT Nome,COUNT(*) NLivros
FROM Autor A, Autoria Au
WHERE A.Autor = Au.Autor
GROUP BY Nome
UNION ALL
SELECT Nome, 0 NLivros
FROM Autor
WHERE Autor NOT IN (SELECT Autor FROM Autoria)

-- Exercicio 21
SELECT Nome
FROM Autor A LEFT JOIN Autoria Au
	ON A.Autor = Au.Autor
GROUP BY Nome
	HAVING COUNT(Livro) = 0
ORDER BY Nome

-- Exercicio 22
SELECT TOP 5 Nome, COUNT(Livro) NLivros
FROM Autor A LEFT JOIN Autoria Au
	ON A.Autor = Au.Autor
GROUP BY Nome
ORDER BY NLivros DESC

-- Exercicio 23
SELECT TOP 1 Titulo, Edicao
FROM Livro
ORDER BY Edicao DESC

-- Exercicio 24
SELECT L.Editora, Titulo, Edicao
FROM Livro L
INNER JOIN
(SELECT Editora, MAX(Edicao) MaxEdicao
FROM Livro
GROUP BY Editora) L1
	ON L.Editora = L1.Editora AND L.Edicao = L1.MaxEdicao

-- Exercicio 25
SELECT L.Editora, COUNT(Livro) NLivros
FROM Livro L
INNER JOIN
(SELECT Editora, MAX(Edicao) MaxEdicao
FROM Livro
GROUP BY Editora) L1
	ON L.Editora = L1.Editora AND L.Edicao = L1.MaxEdicao
GROUP BY L.Editora

-- Exercicio 26
SELECT Nome
FROM Autor A INNER JOIN Autoria Au
	ON A.Autor = Au.Autor
	INNER JOIN Livro L
	ON Au.Livro = L.Livro
WHERE Editora IN
		(SELECT Editora
		FROM Livro L INNER JOIN Autoria Au
			ON L.Livro = Au.Livro
		GROUP BY Editora
			HAVING COUNT(Autor) = 1)

-- Exercicio 27
SELECT Nome
FROM Autor A INNER JOIN Autoria Au
	ON A.Autor = Au.Autor
	INNER JOIN Livro L ON Au.Livro = L.Livro
GROUP BY Nome	
	HAVING COUNT(DISTINCT Editora) > 1

-- Exericio 28
SELECT DISTINCT Nome
FROM Autor A INNER JOIN Autoria Au
	ON A.Autor = Au.Autor
WHERE Livro IN 
		(SELECT L.Livro
		FROM Livro L INNER JOIN Autoria Au
			ON L.Livro = Au.Livro
		GROUP BY L.Livro
			HAVING COUNT(Autor) > 1)

-- Exercicio 29
SELECT A1.Nome, A2.Nome
FROM 
	(SELECT Nome, COUNT(Livro) NLivros
	FROM Autor A INNER JOIN Autoria Au
		ON A.Autor = Au.Autor
	GROUP BY Nome) A1
INNER JOIN
	(SELECT Nome, COUNT(Livro) NLivros
	FROM Autor A INNER JOIN Autoria Au
		ON A.Autor = Au.Autor
	GROUP BY Nome) A2
ON A1.NLivros = A2.NLivros
WHERE A1.Nome > A2.Nome

-- Exercicio 30
UPDATE Item
	SET Valor = Quantidade * Preco
FROM Item I INNER JOIN Livro L
	ON I.Livro = L.Livro
WHERE Valor IS NULL

-- Exercicio 31
UPDATE Factura
	SET Total = TFact
FROM Factura F INNER JOIN
	(SELECT Factura, SUM(Valor) TFact
		FROM Item
	 GROUP BY Factura) T 
		ON F.Factura = T.Factura
WHERE Total IS NULL

-- Exercicio 32
DELETE FROM Recibo
	WHERE Data_pagamento IS NULL


-- Exercicio 33
--  Inserir factura
INSERT Factura (Cliente)
	VALUES (3)

--  Inserir items da factura
INSERT Item (Factura, Item, Livro, Quantidade)
	VALUES (15,1,12,1)
INSERT Item (Factura, Item, Livro, Quantidade)
	VALUES (15,2,4,2)
INSERT Item (Factura, Item, Livro, Quantidade)
	VALUES (15,3,6,1)

-- Exercicio 34
INSERT Recibo (Factura)
	SELECT Factura	
	 FROM Factura
	WHERE Total > 75
		AND Factura NOT IN (SELECT Factura FROM Recibo)
	