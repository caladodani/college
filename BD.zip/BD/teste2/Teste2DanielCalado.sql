-- Daniel Calado 11064115
--Base de Dados 01/06/2017
use Restaurante
--Exercicio 1


SELECT * FROM PRODUTO ORDER BY PRECOUNITARIO 

--Exercicio 2 
SELECT DISTINCT DESCRICAO FROM PRODUTO

--Exercicio 3

SELECT DISTINCT Descricao FROM Localizacao
WHERE Localizacao.CodLocal NOT IN (SELECT CodLocal FROM Mesa)

--Exercicio 4

SELECT DISTINCT Nome
	FROM Cliente INNER JOIN Fatura
		ON Cliente.NIF = Fatura.NIF
	ORDER BY Nome

--EXERCICIO 5

SELECT NumPedido, Descricao
FROM (Pedido INNER JOIN Mesa ON Pedido.CodMesa = Mesa.CodLocal) INNER JOIN Localizacao
	ON Mesa.CodLocal = Localizacao.CodLocal

--EXERCICIO 6 
select TOP 1 Fatura.NIF ,COUNT (NumFatura) QUANTIDADE_DE_FACTURAS
from Fatura
group by Fatura.NIF
ORDER BY COUNT(NumFatura) DESC


--EXERCICIO 7
SELECT DISTINCT Cliente.NIF,Nome,Morada,CodPostal FROM Cliente
WHERE Cliente.NIF NOT IN (SELECT NIF FROM Fatura)


--EXERCICIO 8

SELECT DISTINCT Descricao, SUM(Quantidade) Vendidos
FROM(Produto LEFT JOIN DetalhePedido
	ON Produto.CodProduto = DetalhePedido.CodProduto)
GROUP BY Descricao

--EXERCICIO 9 

SELECT Descricao, Quantidade, PrecoUnitario, DataHora
FROM( Produto INNER JOIN DetalhePedido
	ON Produto.CodProduto = DetalhePedido.CodProduto)
	INNER JOIN Pedido
	ON Pedido.NumPedido = DetalhePedido.NumPedido
ORDER BY DataHora

--EXERCICIO 10

SELECT Nome, Cliente.NIF, DataFatura, SUM(Quantidade * PrecoUnitario) Total_DA_FATURA
	FROM (Produto PRO INNER JOIN DetalhePedido DET
		ON PRO.CodProduto = DET.CodProduto)
		INNER JOIN Fatura
		ON Fatura.NumPedido = DET.NumPedido
		INNER JOIN Cliente
		ON Cliente.NIF = Fatura.NIF
GROUP BY Nome, Cliente.NIF, DataFatura
ORDER BY DataFatura

--EXERCICIO 11

SELECT Cliente.Nome, Cliente.NIF, DetalhePedido.NumPedido, Produto.Descricao, SUM(Quantidade * PrecoUnitario) Valor_Detalhe, Mesa.CodMesa, Localizacao.Descricao
	FROM (Cliente INNER JOIN Fatura
		ON Cliente.NIF = Fatura.NIF)
		INNER JOIN Pedido
		ON Fatura.NumPedido = Pedido.NumPedido
		INNER JOIN Mesa
		ON Pedido.CodMesa = Mesa.CodMesa
		INNER JOIN Localizacao
		ON Localizacao.CodLocal = Mesa.CodLocal
		INNER JOIN DetalhePedido
		ON DetalhePedido.NumPedido = Fatura.NumPedido
		INNER JOIN Produto
		ON Produto.CodProduto = DetalhePedido.CodProduto
GROUP BY Localizacao.Descricao, Cliente.Nome, Cliente.NIF, DetalhePedido.NumPedido, Produto.Descricao, Mesa.CodMesa
