--DANIEL CALADO N� 11064115

--GRUPO II
--EXERCICIO 5 
SELECT * FROM Medico ORDER BY NomeMedico
--EXERCICIO 6  
SELECT DISTINCT MED.NomeMedico, COUNT(*) N_Especialidades
FROM(Medico MED INNER JOIN EspecialidadeMedico ESPMED
    ON MED.CodMedico = ESPMED.CodMedico)
INNER JOIN Especialidade ESP
    ON ESP.CodEspecialidade = ESPMED.CodEspecialidade
GROUP BY MED.NomeMedico
--EXERCICIO 7 
SELECT Designacao, COUNT(CodDoente) AS NumeroDoentes
FROM Enfermaria INNER JOIN Acamado
    ON Enfermaria.CodEnfermaria = Acamado.CodEnfermaria
GROUP BY Designacao 
--EXERCICIO 8 
SELECT DISTINCT TOP 1 NomeDoente, COUNT(Cama) AS NCamas
FROM Doente D INNER JOIN Acamado ACAM
    ON D.CodDoente = ACAM.CodDoente
GROUP BY NomeDoente 
--EXERCICIO 9 
SELECT NomeDoente,  COUNT(ContraIndicacoes) AS Numero_Tratamentos_Em_Curso
FROM Doente D INNER JOIN Acamado ACAM
    ON D.CodDoente = ACAM.CodDoente
INNER JOIN Tratamento TRAT
    ON ACAM.CodDoente = TRAT.CodDoente
INNER JOIN TipoTratamento TPTRAT
    ON TRAT.CodDoenca = TPTRAT.CodDoenca
WHERE DataFim IS NULL
GROUP BY NomeDoente
ORDER BY NomeDoente
--EXERCICIO 10 
SELECT DISTINCT Designacao, NomeDoente, NomeMedico, NomeMedicamento, NomeDoenca, NomeEquipamento, DataFim
FROM Doente D INNER JOIN Acamado ACAM
    ON D.CodDoente = ACAM.CodDoente
INNER JOIN Acamado
    ON Acamado.CodDoente = ACAM.CodDoente
INNER JOIN Enfermaria
    ON Enfermaria.CodEnfermaria = Acamado.CodEnfermaria
INNER JOIN Tratamento TRAT
    ON ACAM.CodDoente = TRAT.CodDoente
INNER JOIN Terapia
    ON Terapia.CodDoenca = TRAT.CodDoenca
INNER JOIN Medicamento
    ON Medicamento.CodMedicamento = Terapia.CodMedicamento
INNER JOIN EspecialidadeMedico
    ON TRAT.CodMedico = EspecialidadeMedico.CodMedico
INNER JOIN Medico
    ON Medico.CodMedico = EspecialidadeMedico.CodEspecialidade
INNER JOIN TipoTratamento TPTRAT
    ON TRAT.CodDoenca = TPTRAT.CodDoenca
INNER JOIN Equipamento E
    ON E.CodEquipamento = TPTRAT.CodEquipamento
INNER JOIN Doenca Do
    ON TPTRAT.CodDoenca = Do.CodDoenca
WHERE DataFim BETWEEN '2016-01-01' AND '2016-12-31' 
ORDER BY Designacao, NomeDoente

