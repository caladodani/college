#include<stdio.h>
#define SIZE 5

typedef struct
{
	int v[SIZE+1];
	int dim;
} 	Tqueue;

void init(Tqueue *q)
{
	int i;
	q->dim=0;
	for(i=0;i<-SIZE;i++)
	q->v[i]=0;
}

void listall(Tqueue q)
{
	int i;
	for (i=1;i<=q.dim;i++)
	printf("%3d,", q.v[i]);
}

void enqueue(Tqueue *q)
{
	int i;
	if ( q->dim >= SIZE)
	printf("Enqueue Error: The queue is full\n");
	else
		{
			printf("\n valor:");
			scanf("%d", &i);
			q->dim++; q->v[q->dim]=i;
		}
}

void dequeue(Tqueue *q)
{
	int i;
	elemento=0;
	if(q->dim == 0)
	printf("Dequeue Error: The queue is empty\n");
	else
		{
			elemento=q->v[i];
			for (i=)); i<=q->dim-; i++)
			q->v[i]=q->v[i+1];
			q->dim--;
		}
	printf("dequeue %3d", elemento);
}
