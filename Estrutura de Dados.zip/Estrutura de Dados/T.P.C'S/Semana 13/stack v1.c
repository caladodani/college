#include <stdio.h>
#define SIZE 5

int  stack[SIZE];
int  dim;

void push() //carregar
{     int i;
      if(dim==SIZE)printf("Stack Overflow.\n");
      else {  printf("\nvalor:"); scanf("%d",&i); 
                 stack[dim]=i; dim++;
               }
}

void pop(void)
{      int  elemento=0;
       if (dim==0) printf("Stack Underflow.\n");
       else  {elemento=stack[dim-1]; dim--;}
       printf("Pop %3d",elemento);
}

void repetir()
{ char opcao;
  do
  {      opcao=menu();
         switch(opcao)
              { case 1: push(); break;
                case 2: pop(); break;
                case 3: print(); break;
                default: printf("Opcao invalida\n");
              }
  } while(opcao!=0);
  printf("Fim do programa.\n");
}

void print()
{ int i; 
  for (i=0;i<dim;i++)printf("%3d,",stack[i]);
}


int menu()
{  int opcao;
    printf("\n \n");
    printf("1-Push     \n");
    printf("2-Pop      \n");
    printf("3-Listar   \n");
    printf("0-Sair     \n");
    printf("Opcao: ");                                            
    scanf("%d",&opcao);
    return opcao;
}

int main()
{
	repetir(menu);

}

