#include <stdio.h>
#define SIZE 5

typedef struct
{   int  v[SIZE];
     int  dim;
} Tstack;


void push(Tstack *s) //carregar
{ int i;
  if( s->dim == SIZE) printf("Stack Overflow.\n");
  else {printf("\nvalor:"); scanf("%d",&i); 
            s->v[s->dim]=i; s->dim++;
        }
}

void pop(Tstack *s)
{  int elemento=0;
   if(s->dim == 0) printf("Stack Underflow.\n");
   else {elemento=s->v[s->dim-1]; s->dim--;}
   printf("Pop %3d",elemento);
}

void init(Tstack *s)
{ int i; s->dim=0;
  for (i=0;i<SIZE;i++)s->v[i]=0;
}

void print(Tstack s)
{ int i; 
  for (i=0;i < s.dim;i++)printf("%3d,",s.v[i]);
}

int menu()
{  int opcao;
    printf("\n \n");
    printf("1-Push     \n");
    printf("2-Pop      \n");
    printf("3-Listar   \n");
    printf("0-Sair     \n");
    printf("Opcao: ");                                            
     scanf("%d",&opcao);
    return opcao;
}

void repetir(Tstack s)
{ char opcao;
  do
  { opcao=menu();
    switch(opcao)
    { case 1: push(&s);  break;
      case 2: pop(&s);   break;
      case 3: print(s);  break;
      default: printf("Opcao invalida\n");
    }
  } while(opcao!=0);
  printf("Fim do programa.\n");
}

int main()
{  Tstack stack;
   init(&stack);
   repetir(stack);
   return 0;	
}

