#include <stdio.h>

int main ()
{ int n=4;
 printf("indique o numero:");  scanf("%d",&n);
int fatorial=1;
int i;
for(i=1; i<=numero;i++)
{ fatorial=fatorial*i;
printf("\nfatorial[%i]=%i",i,fatorial);
}
}
