#include <stdio.h>

int main()
{ char c;
for(c='a'; c <='z'; c++) printf("\nLetra %c = %d",c,c);
return 0;
}
