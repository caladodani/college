#include <stdio.h>

int max2 (int x1, int x2)
{ 
	if (x1>x2) return x1;
	else return x2;
}

int max3 (int x1, intx2, intx3)
{ 
	return max2(x1, max2(x2,x3));
}

int entre (x1,x2,x3)
{ 
	return x1+x2+x3-max3(x1,x2,x3)-min3(x1,x2,x3);
}
