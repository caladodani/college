#include <stdio.h>

int main()
{
	int numero;
	printf("indique um numero: ");
	scanf("%d",&numero);
	if(numero%2) printf("impar");
	else printf("par");
	
	getchar();
	return 0;
	
}
