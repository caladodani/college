#include <stdio.h>

int main()
{ int soma=0, i=1;
while(i<=4)
{soma=soma+i*i;
i=i+1;
}
printf("Soma dos primeiros 4 quadrados: %d", soma);
return 0;
}
