#include <stdio.h>

int main()
{
	char c='a';
	while(c <= 'z')
	{ printf("\nLetra %c = %d",c,c);
	c=c+1;
	}
	return 0;
}
