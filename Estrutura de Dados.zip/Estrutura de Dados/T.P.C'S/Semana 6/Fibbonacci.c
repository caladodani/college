#include <stdio.h>

int FibonacciR(int n)
{
	if(n == 0) 
		return 1;
	else if (n ==1)
		return 1;
	else return FibonacciR(n-1) + FibonacciR(n-2);
}

int main()
{	int n;
	printf("Indique o numero: ");
	scanf("%d", &n);
	FibonacciR(n);
	printf("Fibonnaci %d= %d", n, FibonacciR(n));
	return 0;
}
