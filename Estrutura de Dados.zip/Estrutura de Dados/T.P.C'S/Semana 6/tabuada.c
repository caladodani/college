# include <stdio.h>

void tabuada(int n)
{
	int i;
	for(i=1; i<=10; i++)
	{
		printf(" %d * %d = %d \n", n, i, n*i);
	}
	
}
void todas()
{
	int i;
	for(i=2; i<=9; i++)
	{
	 tabuada(i);
	 printf("\n");
	}
	
}


int main()
{
	//int n;
	//printf("Indique um numero:");
	
	//scanf("%d", &n);
	//tabuada(n);
	todas();
	
	//int n= 15;
	//int i= 2;
	//	printf(" %d + %d = %d \n", n, i, n+i);
	//		printf(" %d - %d = %d \n", n, i, n-i);
	//			printf(" %d / %d = %d \n", n, i, n/i);
	//				printf(" %d * %d = %d \n", n, i, n*i);
	//					printf(" %d mod %d = %d \n", n, i, n % i);
	
}
