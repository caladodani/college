#include <stdio.h>
# define N 5
int vector[N+1];

void vector_carregar()
{ int i;
	vector[0]=0; printf("Entrada de dados\n");
	for(i=1; i<=N; i=i+1)
	{ printf(" v[%d]=", i);scanf("%d",&vector[i]);
	}
}

void vector_escrever()
{ int i;
	for(i=1; i<=N;i=i+1) printf("\n v[%d]=%d",i,vector[i]);
}

int vector_max()
{ int i, max;
	max=-32000;
	for(i=1;i<=N;i=i+1)
	{
		if(vector[i]>max) max=vector[i];
	}
	return max;
}

int vector_min()
{
	int i, min;
	min=32000;
	for(i=1;i<=N;i++)
	{ 
		if(vector[i]<min) min=vector[i];
	}
}

int main()
{
	vector_carregar();
	vector_escrever();
	printf("\n Max= %d", vector_max());
	printf("\n Min=%d", vector_min());
}
