#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define N 10

int vector[N+1]={1,10,2,5,50,9,0,0,0};

/*void randomNumbers()
{
	int i;
	int seed = 11;
	srand(seed);
	for(i=0; i<10; i++)
	printf("%2d\n", rand()%100);
}*/

/*void elaspedTime(void)
{
	time_t strat, end;
	start = time(NULL);
	randomNumbers();
	end = time(NULL);
	printf("Elapsed Time: %f seconds\n", difftime(end, start));
} */

void trocar(int *x, int *y)
{
	int aux = *x;
	*x = *y;
	*y = aux; 
}

/*void inserir_fim()
{
	int i;
	vecto[0]=0;
	printf("Entrada de dados\n");
	for(i=1; i<=N; i=i+1)
	{
		printf(" v[%d]=", i);
		scanf("%d", &vector[i]);
	}
}*/

void bubbleSort(int vector[],int nn)
{   int i, n=nn, trocou;
    do
    {  trocou=0;
       for (i=2; i<=n; i++)
           if (vector[i-1]>vector[i]) {trocar(&vector[i-1],&vector[i]); trocou=1;}
       n=n-1;
    } while (trocou);
}

void escrever (int n)
{
	int i;
	for(i=1; i<=n; i++)
	printf("v[%d] = %2d", i, vector[i]);
}

int main()
{	escrever(vector[0]);

	bubbleSort(vector, vector[0]);
	
	return 0;
}
