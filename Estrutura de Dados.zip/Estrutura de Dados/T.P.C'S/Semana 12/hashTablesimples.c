#include <stdio.h>
#define max_hash 173

int table[max_hash];

int hash (int n)
{  return n%max_hash;
}

int clearTable(int v[])
{   int i;
    for (i=0;i<max_hash;i++) table[i]=0;	
}

int printTable(int v[])
{   int i;
    for (i=0;i<max_hash;i++) printf("%i ",table[i]);	
}

int insertTable (int valor, int v[])
{  int ii= hash(valor);
   if(v[ii]==0) v[ii]=valor;
   else printf("\n colision...\n");	
}

void loadTable(int v[])
{	clearTable(v);
	insertTable (458,v); insertTable (210,v); insertTable (48,v);
	insertTable (123,v); insertTable (167,v); insertTable (959,v);
	insertTable (172,v); insertTable (4381,v); insertTable (356,v);
	insertTable (16,v);
}

/*int findTable(int valor, int v[])
{  return (v[hash(valor)]==valor);
}*/

int main()
{
	int valor;
	loadTable(table);
	printTable(table);
	insertTable(valor, table);
	loadTable(table);
	return 0;
}

