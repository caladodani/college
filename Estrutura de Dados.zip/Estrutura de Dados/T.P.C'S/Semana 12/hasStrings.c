#include <stdio.h>
#include <string.h>
#define N 80

char str[N];

void string_limpar()
{
	strcpy(str, "");
}

void string_inserir()
{
	printf("string: "); fflush(stdin); gets(str);
}

void string_escrever()
{
	printf("%s, length = %d\n", str, strlen(str));
}

int string_igual( char nome[])
{
	if (strcmp(str, nome)==0)
	return 1;
	else
	return 0;
}
