# include <string.h>
# define  max_hash   11

char table[max_hash][20];

int hash (char s[])
{  int n=strlen(s);  
   return (s[0]+s[n-1]+16*n)%MAX_HASH;
}

int clearTable(char v[][20])
{   int i; 	
    for (i=0;i<MAX_HASH;i++)  strcpy(v[i],"");	
}

int printTable(char v[][20])
{   int i;
	for (i=0;i<MAX_HASH;i++) printf("(%2i) %s \n",i,v[i]);	
}

int insertTable(char* valor, char v[][20])
{  int ii= hash(valor);
   if (strcmp(v[ii],"")==0)  strcpy(v[ii],valor);
   else printf("colision...");	
}

void loadTable(char v[][20])
{	char s[20];
	clearTable(v); 
	strcpy(s,"a125"); insertTable (s,v); 
	strcpy(s,"b213"); insertTable (s,v); 
	strcpy(s,"c624"); insertTable (s,v);
	strcpy(s,"d166"); insertTable (s,v); 
    strcpy(s,"e179"); insertTable (s,v);  
    strcpy(s,"f922"); insertTable (s,v);
}

int main()
{
	int valor;
	loadTable(table);
	printTable(table);
	insertTable(valor, table);
	loadTable(table);
	return 0;
}

